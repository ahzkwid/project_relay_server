﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MocaEngine
{
    //ver 0.6.3 Lite




    public struct mStr_screen
    {
        public string str;
        public mVec2 pos;
        public mStr_screen(string Str)
        {
            this.str = Str;
            this.pos.x = -1;
            this.pos.y = -1;
        }
        public mStr_screen(string Str, float X, float Y)
        {
            this.str = Str;
            this.pos.x = X;
            this.pos.y = Y;
        }
        public mStr_screen(string Str, mVec2 Pos)
        {
            this.str = Str;
            this.pos = Pos;
        }
    }
    public struct mVec2
    {
        public float x, y;
        public mVec2(float X, float Y)
        {
            this.x = X;
            this.y = Y;
        }
        public static mVec2 zero
        {
            get
            {
                return new mVec2(0f, 0f);
            }
        }
        public static mVec2 one
        {
            get
            {
                return new mVec2(1f, 1f);
            }
        }
        public static mVec2 operator +(mVec2 _Vec1, mVec2 _Vec2)
        {
            _Vec1.x += _Vec2.x;
            _Vec1.y += _Vec2.y;
            return _Vec1;
        }
        public static mVec2 operator -(mVec2 _Vec1, mVec2 _Vec2)
        {
            _Vec1.x -= _Vec2.x;
            _Vec1.y -= _Vec2.y;
            return _Vec1;
        }
        public static mVec2 operator -(mVec2 _Vec)
        {
            _Vec.x = -_Vec.x;
            _Vec.y = -_Vec.y;
            return _Vec;
        }


        public static bool operator ==(mVec2 _Vec, float _var)
        {
            return (_Vec.x == _var) && (_Vec.y == _var);
        }
        public static bool operator !=(mVec2 _Vec, float _var)
        {
            return (_Vec.x != _var) || (_Vec.y != _var);
        }
        public static bool operator ==(mVec2 _Vec1, mVec2 _Vec2)
        {
            return (_Vec1.x == _Vec2.x) && (_Vec1.y == _Vec2.y);
        }
        public static bool operator !=(mVec2 _Vec1, mVec2 _Vec2)
        {
            return (_Vec1.x != _Vec2.x) || (_Vec1.y != _Vec2.y);
        }


    }
    public struct mVec4
    {
        public float x, y, z, w;
        public mVec4(float X, float Y, float Z, float W)
        {
            this.x = X;
            this.y = Y;
            this.z = Z;
            this.w = W;
        }
    }
    //public class mScript : MonoBehaviour

    public static class mString
    {
        public static string[] line_to_array(string str)
        {
            //long str_buffer_size = 0;
            long str_buffer_num = 0;
            string[] str_buffer = null;

            long str_buffer_temp_num = 0;
            long str_buffer_temp_size = 64;
            string[] str_buffer_temp = new string[str_buffer_temp_size];

            string str_temp = null;

            StringReader sr = new StringReader(str);

            while (true)
            {
                str_temp = sr.ReadLine();
                if (str_temp != null)
                {
                    if (str_buffer_temp_num >= str_buffer_temp.Length)
                    {
                        str_buffer = mScript.array_add<string>(str_buffer, str_buffer_temp);
                        str_buffer_temp_num = 0;
                        str_buffer_temp_size *= 2;
                        str_buffer_temp = new string[str_buffer_temp_size];
                    }
                    str_buffer_temp[str_buffer_temp_num] = str_temp;
                    str_buffer_num++;
                    str_buffer_temp_num++;
                }
                else
                {
                    str_buffer = mScript.array_add<string>(str_buffer, str_buffer_temp_num, str_buffer_temp);
                    break;
                }
            }

            return str_buffer;
        }
    }
    public static class mFile
    {

        public static bool save(string filename, string value)
        {
            FileStream fs = new FileStream(filename, FileMode.Create);
            StreamWriter st = new StreamWriter(fs, Encoding.UTF8);
            st.Write(value);
            st.Close();
            fs.Close();
            return true;
        }
        public static string read(string filename)
        {
            if (!System.IO.File.Exists(filename))
            {
                return null;
            }
            FileStream fs = new FileStream(filename, FileMode.Open);
            StreamReader st = new StreamReader(fs, Encoding.UTF8);
            string _return = "";
            _return = st.ReadToEnd();


            st.Close();
            fs.Close();
            return _return;
        }

        public static bool delete(string filename)
        {
            if (!System.IO.File.Exists(filename))
            {
                return false;
            }
            System.IO.File.Delete(filename);
            return true;
        }
        public static string search()
        {
            OpenFileDialog openFile = new OpenFileDialog();
            //openFile.DefaultExt = "png";
            openFile.Filter = "All files(*.*)|*.*";
            openFile.ShowDialog();


            if (openFile.FileName.Length > 0)//파일이선택될경우 
            {
                return openFile.FileName;
            }
            return "";
        }
    }

    public struct mQueueLinked<T>
    {
    }
    public struct mQueue<T>
    {
        public T[] QueBuffer;
        public long start;
        private long index;
        public long max;
        public mQueue(T[] _buffer)
        {
            if (_buffer == null)
            {
                this.QueBuffer = null;
            }
            else
            {
                this.QueBuffer = (T[])_buffer.Clone();
            }
            this.start = 0;
            this.index = 0;
            this.max = _buffer.LongLength;
        }

        public void Add(T input)
        {
            if(this.Lenght<this.QueBuffer.LongLength)
            {
                this.QueBuffer[this.max] = input;
                this.max++;
                if(this.max>= this.QueBuffer.LongLength)
                {
                    this.max = 0;
                }
            }
        }
        public long Index
        {
            get
            {
                return this.index - this.start;
            }
            set
            {
                this.index = mScript.median(start, this.start + value, this.max - 1);
            }
        }
        public long Lenght
        {
            get
            {
                if(this.max>= this.start)
                {
                    return this.max - this.start;
                }
                return this.QueBuffer.LongLength - this.start+ this.max;
            }
        }
    }
    public struct mByteBuffer
    {
        public byte[] _buffer;
        private long index;
        private long max;

        
        public mByteBuffer(byte[] _buffer)
        {
            if(_buffer==null)
            {
                this._buffer = null;
            }
            else
            {
                this._buffer = (byte[])_buffer.Clone();
            }
            this.index = 0;
            this.max = _buffer.LongLength;
        }
        public long Index
        {
            get
            {
                return this.index;
            }
            set
            {
                this.index = Math.Min(value, this.max-1);
            }
        }
        public long Lenght
        {
            get
            {
                return this.max;
            }
            set
            {
                this.max = Math.Max(value, 0);
                if (this._buffer==null)
                {
                    this._buffer = new byte[this.max];
                }
                else if(_buffer.LongLength < this.max)
                {
                    this._buffer = mScript.array_add_null<byte>(this._buffer, this.max - _buffer.LongLength);

                }
            }
        }

        public T Read<T>()
        {
            if (mScript.type_check<T, byte>())
            {
                return (T)(Object)ReadByte();
            }
            if (mScript.type_check<T, int>())
            {
                return (T)(Object)ReadInt();
            }
            if (mScript.type_check<T, long>())
            {
                return (T)(Object)ReadLong();
            }
            if (mScript.type_check<T, double>())
            {
                return (T)(Object)ReadDouble();
            }
            if (mScript.type_check<T, string>())
            {
                return (T)(Object)ReadString();
            }
            return (T)new Object();
        }
        public byte ReadByte()
        {
            return this._buffer[this.index++];
        }
        public ushort ReadUShort()
        {
            UInt16 t = BitConverter.ToUInt16(this._buffer, (int)this.index);
            this.index += 16 / 8;
            return t;
        }
        public short ReadShort()
        {
            Int16 t = BitConverter.ToInt16(this._buffer, (int)this.index);
            this.index += 16 / 8;
            return t;
        }
        public int ReadInt()
        {
            Int32 t = BitConverter.ToInt32(this._buffer, (int)this.index);
            this.index += 32 / 8;
            return t;
        }
        public long ReadLong()
        {
            long t = BitConverter.ToInt64(this._buffer, (int)this.index);
            this.index += 64 / 8;
            return t;
        }
        public double ReadDouble()
        {
            double t = BitConverter.ToDouble(this._buffer, (int)this.index);
            this.index += 64 / 8;
            return t;
        }
        public string ReadString()
        {
            long index_t = this.index;
            long length = 0;
            for (int i = 0; i < 65535; i++)
            {
                if (this.ReadByte() == 0)
                {
                    break;
                }
            }
            length = this.index - 1 - index_t;
            if(length<=0)
            {
                return "";
            }
            return Encoding.UTF8.GetString(mScript.array_slice<Byte>(this._buffer, index_t, length));
        }
        /*
        public string ReadString()
        {
            long length = this.ReadLong();
            string return_str= Encoding.UTF8.GetString(mScript.array_slice<Byte>(this._buffer, this.index, length));
            this.index += length;
            return return_str;
        }
        public void AddGMS(params string[] Array)
        {
            WriteStringGMS(Array);
        }
        public void WriteGMS(params string[] Array)
        {
            WriteStringGMS(Array);
        }
        public void WriteStringGMS(params string[] Array)
        {
            for (long i = 0; i < Array.LongLength; i++)
            {
                this.Add(mScript.get_byte(Array[i]));
            }
            this.Add((byte)0);
        }
        public string ReadStringGMS()
        {
            long index_t = this.index;
            long length = 0;
            for (int i=0;i<65535;i++)
            {
                if (this.ReadByte() == 0)
                { 
                    break;
                }
            }
            length = this.index- index_t -1;
            return Encoding.UTF8.GetString(mScript.array_slice<Byte>(this._buffer, index_t, length));
        }
        */
        public T SafetyRead<T>(int CopyNumber)
        {
            if (CopyNumber > 255)
            {
                CopyNumber = 255;
            }
            T[] _t = new T[CopyNumber];
            byte[] check = new byte[CopyNumber];
            int j;
            for (int i = 0; i < CopyNumber; i++)
            {
                _t[i] = this.Read<T>();
            }
            for (int i = 0; i < CopyNumber; i++)
            {
                for (j = i + 1; j < CopyNumber; j++)
                {
                    if (_t[i].Equals(_t[j]))
                    {
                        check[i]++;
                        check[j]++;
                    }
                }
            }
            j = 0;
            for (int i = 1; i < CopyNumber; i++)
            {
                if (check[i] > check[j])
                {
                    j = i;
                }
            }
            return _t[j];
        }
        public byte SafetyReadByte(int CopyNumber)
        {
            if(CopyNumber>255)
            {
                CopyNumber = 255;
            }
            byte[] _t = new byte[CopyNumber];
            byte[] check = new byte[CopyNumber];
            int j;
            for (int i = 0; i < CopyNumber; i++)
            {
                _t[i] = this.ReadByte();
            }
            for (int i = 0; i < CopyNumber; i++)
            {
                for (j = i+1; j < CopyNumber; j++)
                {
                    if(_t[i]== _t[j])
                    {
                        check[i]++;
                        check[j]++;
                    }
                }
            }
            j = 0;
            for (int i = 1; i < CopyNumber; i++)
            {
                if (check[i] > check[j])
                {
                    j = i;
                }
            }
            return _t[j];
        }
        public int SafetyReadInt(int CopyNumber)
        {
            if (CopyNumber > 255)
            {
                CopyNumber = 255;
            }
            int[] _t = new int[CopyNumber];
            byte[] check = new byte[CopyNumber];
            int j;
            for (int i = 0; i < CopyNumber; i++)
            {
                _t[i] = this.ReadInt();
            }
            for (int i = 0; i < CopyNumber; i++)
            {
                for (j = i + 1; j < CopyNumber; j++)
                {
                    if (_t[i] == _t[j])
                    {
                        check[i]++;
                        check[j]++;
                    }
                }
            }
            j = 0;
            for (int i = 1; i < CopyNumber; i++)
            {
                if (check[i] > check[j])
                {
                    j = i;
                }
            }
            return _t[j];
        }
        public long SafetyReadLong(int CopyNumber)
        {
            if (CopyNumber > 255)
            {
                CopyNumber = 255;
            }
            long[] _t = new long[CopyNumber];
            byte[] check = new byte[CopyNumber];
            int j;
            for (int i = 0; i < CopyNumber; i++)
            {
                _t[i] = this.ReadLong();
            }
            for (int i = 0; i < CopyNumber; i++)
            {
                for (j = i + 1; j < CopyNumber; j++)
                {
                    if (_t[i] == _t[j])
                    {
                        check[i]++;
                        check[j]++;
                    }
                }
            }
            j = 0;
            for (int i = 1; i < CopyNumber; i++)
            {
                if (check[i] > check[j])
                {
                    j = i;
                }
            }
            return _t[j];
        }
        public double SafetyReadDouble(int CopyNumber)
        {
            if (CopyNumber > 255)
            {
                CopyNumber = 255;
            }
            double[] _t = new double[CopyNumber];
            byte[] check = new byte[CopyNumber];
            int j;
            for (int i = 0; i < CopyNumber; i++)
            {
                _t[i] = this.ReadDouble();
            }
            for (int i = 0; i < CopyNumber; i++)
            {
                for (j = i + 1; j < CopyNumber; j++)
                {
                    if (_t[i] == _t[j])
                    {
                        check[i]++;
                        check[j]++;
                    }
                }
            }
            j = 0;
            for (int i = 1; i < CopyNumber; i++)
            {
                if (check[i] > check[j])
                {
                    j = i;
                }
            }
            return _t[j];
        }
        public string SafetyReadString(int CopyNumber)
        {
            if (CopyNumber > 255)
            {
                CopyNumber = 255;
            }
            string[] _t = new string[CopyNumber];
            byte[] check = new byte[CopyNumber];
            int j;
            for (int i = 0; i < CopyNumber; i++)
            {
                _t[i] = this.ReadString();
            }
            for (int i = 0; i < CopyNumber; i++)
            {
                for (j = i + 1; j < CopyNumber; j++)
                {
                    if (_t[i] == _t[j])
                    {
                        check[i]++;
                        check[j]++;
                    }
                }
            }
            j = 0;
            for (int i = 1; i < CopyNumber; i++)
            {
                if (check[i] > check[j])
                {
                    j = i;
                }
            }
            return _t[j];
        }
        public void SafetyWrite(byte input)
        {
            this.SafetyWrite(input, 3);
        }
        public void SafetyWrite(int input)
        {
            this.SafetyWrite(input, 3);
        }
        public void SafetyWrite(long input)
        {
            this.SafetyWrite(input, 3);
        }
        public void SafetyWrite(string input)
        {
            this.SafetyWrite(input, 3);
        }
        public void SafetyWrite(byte input, int CopyNumber)
        {
            for (int i = 0; i < CopyNumber; i++)
            {
                this.Add(input);
            }
        }
        public void SafetyWrite(int input, int CopyNumber)
        {
            for (int i = 0; i < CopyNumber; i++)
            {
                this.Add(input);
            }
        }
        public void SafetyWrite(long input, int CopyNumber)
        {
            for (int i = 0; i < CopyNumber; i++)
            {
                this.Add(input);
            }
        }
        public void SafetyWrite(double input, int CopyNumber)
        {
            for (int i = 0; i < CopyNumber; i++)
            {
                this.Add(input);
            }
        }
        public void SafetyWrite(string input, int CopyNumber)
        {
            for (int i = 0; i < CopyNumber; i++)
            {
                this.Add(input);
            }
        }
        public void AddAt(long _index, params int[] Array)
        {
            for (long i = 0; i < Array.LongLength; i++)
            {
                this.AddAt(_index,mScript.get_byte(Array[i]));
            }
        }
        public void AddAt(long _index, params long[] Array)
        {
            for (long i = 0; i < Array.LongLength; i++)
            {
                this.AddAt(_index, mScript.get_byte(Array[i]));
            }
        }
        public void AddAt(long _index, params double[] Array)
        {
            for (long i = 0; i < Array.LongLength; i++)
            {
                this.AddAt(_index, mScript.get_byte(Array[i]));
            }
        }
        public void AddAt(long _index, params string[] Array)
        {
            byte[] t;
            for (long i = 0; i < Array.LongLength; i++)
            {
                t = mScript.get_byte(Array[i]);
                this.AddAt(_index, t);
                this.AddAt(_index,t.Length);
            }
        }
        public void Add(params int[] Array)
        {
            for(long i=0;i< Array.LongLength;i++)
            {
                this.Add(mScript.get_byte(Array[i]));
            }
        }
        public void Add(params long[] Array)
        {
            for (long i = 0; i < Array.LongLength; i++)
            {
                this.Add(mScript.get_byte(Array[i]));
            }
        }
        public void Add(params double[] Array)
        {
            for (long i = 0; i < Array.LongLength; i++)
            {
                this.Add(mScript.get_byte(Array[i]));
            }
        }

        public void Add(params string[] Array)
        {
            for (long i = 0; i < Array.LongLength; i++)
            {
                this.Add(mScript.get_byte(Array[i]));
            }
            this.Add((byte)0);
        }
        public void Add(params EndPoint[] Array)
        {
            for (long i = 0; i < Array.LongLength; i++)
            {
                this.Add(mScript.get_byte(Array[i]));
            }
        }
        
        /*
        public void Add(params string[] Array)
        {
            byte[] t;
            for (long i = 0; i < Array.LongLength; i++)
            {
                t = mScript.get_byte(Array[i]);
                this.Add(t.Length);
                this.Add(t);
            }
        }
        */
        public void Add(params byte[] Array)
        {
            if (Array == null)
            {
                return;
            }
            if (this._buffer == null)
            {
                this._buffer = new byte[Array.LongLength];
                //return;
            }
            if (this._buffer.LongLength < (this.max + Array.LongLength))
            {
                this._buffer = mScript.array_add_null<byte>(this._buffer, ((this.max + Array.LongLength) * 2)- this._buffer.LongLength);
            }
            for (long i = 0; i < Array.LongLength; i++) //입력받은 값을 넣는다
            {
                this._buffer[this.max] = Array[i];
                this.max++;
            }
        }
        public void Add(params mByteBuffer[] Array)
        {

            if (Array == null)
            {
                return;
            }
            long length_t = 0;
            for (long i = 0; i < Array.LongLength; i++) //입력받은 값을 넣는다
            {
                length_t += Array[i].Lenght;
            }
            if (this._buffer == null)
            {
                this._buffer = new byte[length_t];
            }
            if (this._buffer.LongLength < (this.max + length_t))
            {
                this._buffer = mScript.array_add_null<byte>(this._buffer, ((this.max + length_t) * 2) - this._buffer.LongLength);
            }
            for (long i = 0; i < Array.LongLength; i++) //입력받은 값을 넣는다
            {
                for (long j = 0; j < Array[i].Lenght; j++) //입력받은 값을 넣는다
                {
                    this._buffer[this.max] = Array[i]._buffer[j];
                    this.max++;
                }
            }

            
        }
        public void AddAt(long _index,params byte[] Array)
        {
            if (Array == null)
            {
                return;
            }
            if (this._buffer == null)
            {
                this._buffer = new byte[Array.LongLength];
                //this._buffer = Array;
                //return;
            }
            if (this._buffer.LongLength < (this.max + Array.LongLength))
            {
                this._buffer = mScript.array_add_null<byte>(this._buffer, ((this.max + Array.LongLength) * 2) - this._buffer.LongLength);
            }
            for (long i = this.max + Array.LongLength - 1 ; i >= _index + Array.LongLength; i--) //인덱스 위치부터 크기만큼 뒤로 미룬다
            {
                this._buffer[i] = this._buffer[i- Array.LongLength];
            }
            for (long i = 0; i < Array.LongLength; i++) //입력받은 값을 넣는다
            {
                this._buffer[_index + i] = Array[i];
                this.max++;
            }
        }

        public void Delete()
        {
            this.Delete(0,this.max);
            this.index = 0;
            this.max = 0;
        }
        public void Delete(long offset)
        {
            this.Delete(offset, 1);
        }
        public void Delete(long offset, long _Length)
        {
            //offset is 0 ~ (_array.length - 1))
            if ((_Length <= 0) || (this._buffer == null))
            {
                return;
            }
            if ((offset < 0) || ((offset + _Length) > this.max))//삭제위치가 배열크기를 벗어날경우
            {
                return;
            }
            this.max -= _Length;
            for (long i = offset; i < this.max; i++) //입력받은 값을 넣는다
            {
                this._buffer[i] = this._buffer[i + _Length];
            }
            if(offset < this.index)
            {
                this.Index -= _Length;
                this.Index = Math.Max(offset,this.index);
            }
        }
        public void DeleteHS(long offset)
        {
            this.DeleteHS(offset, 1);
        }
        public void DeleteHS(long offset, long _Length)
        {
            //offset is 0 ~ (_array.length - 1))
            if ((_Length <= 0) || (this._buffer == null))
            {
                return;
            }
            if (((offset >= 0) && ((offset + _Length) <= this.max)) == false)//삭제위치가 배열크기를 벗어날경우
            {
                return;
            }
            for (long i = 0; i < _Length; i++) //입력받은 값을 넣는다
            {
                this._buffer[offset + i] = this._buffer[this.max - 1 - i];
            }
            this.max -= _Length;
            if (offset < this.index)
            {
                this.Index -= offset;
            }
        }
        public byte[] ByteArray
        {
            get
            {
                return mScript.array_slice<byte>(this._buffer,this.max);
            }
            set
            {
                this.max = 0;
                this.Add(value);
            }
        }
        public string StringBuffer
        {
            get
            {
                return Encoding.UTF8.GetString((byte[])this);
            }
            set
            {
                this._buffer = Encoding.UTF8.GetBytes(value);
            }
        }
        public byte XOR
        {
            get
            {

                byte return_byte = 0;
                long input_LongLength = this.max;

                for (long i = 0; i < input_LongLength; i++)
                {
                    return_byte ^= this._buffer[i];
                }
                return return_byte;
                
            }
        }
        public static mByteBuffer None
        {
            get
            {
                return new mByteBuffer();
            }
        }
        public static implicit operator byte[] (mByteBuffer _mbuffer)
        {
            byte[] _return = new byte[_mbuffer.max];
            for (long i = 0; i < _mbuffer.max; i++)
            {
                _return[i] = _mbuffer._buffer[i];
            }
            return _return;
        }
    }
    public static class mNet
    {
        public enum mNetworkType { IPV4, IPV6 };
        public enum mProtocolType { TCP, UDP };

        public struct mMessage
        {
            public System.Net.EndPoint EP;
            public mByteBuffer _buffer;
            public long index;

            public mMessage(EndPoint EP, byte[] _buffer)
            {
                this.EP = EP;
                this._buffer = new mByteBuffer(_buffer);
                this.index = 0;
            }
            public mMessage(EndPoint EP, mByteBuffer _buffer)
            {
                this.EP = EP;
                this._buffer = _buffer;
                this.index = 0;
            }
            public void Delete()
            {
                this._buffer.Delete();
                this.index = 0;
            }
            /*
            public mMessage(string IP, string Port)
            {
                this.EP = new System.Net.IPEndPoint(System.Net.IPAddress.Parse(IP), Int32.Parse(Port));
                this._buffer = null;
                this.index = 0;
            }
            public mMessage(System.Net.IPAddress IP, Int32 Port)
            {
                this.EP = new System.Net.IPEndPoint(IP, Port);
                this._buffer = null;
                this.index = 0;
            }
            public mMessage(System.Net.IPAddress IP, Int32 Port, mByteBuffer[] _buffer)
            {
                this.EP = new System.Net.IPEndPoint(IP, Port);
                this._buffer = _buffer;
                this.index = 0;
            }
            */
            /*
            public byte[] ByteArray
            {
                get
                {
                    return mScript.array_slice<byte>(this._buffer, this.max);
                }
                set
                {
                    this.max = 0;
                    this.Add(value);
                }
            }
            */
            public byte[] Rapping(mUser User)
            {
                /*
                public long HashKey;
                public String Name;
                public long AppKey;
                public System.Net.IPEndPoint EndPoint;
                public long Ping_Time;
                public long Level;
                public long State;
            */
                mByteBuffer mbuff_t = mByteBuffer.None;
                byte[] buff_t = this._buffer.ByteArray;
                mbuff_t.Add("rapping");
                mbuff_t.Add((int)0); //format type nomal
                if(buff_t==null)
                {
                    mbuff_t.Add((int)0);
                }
                else
                {
                    mbuff_t.Add((int)buff_t.LongLength);
                }
                mbuff_t.Add(mScript.get_xor_byte(buff_t));
                mbuff_t.Add((int)User.AppKey);
                mbuff_t.Add((int)User.ID);
                mbuff_t.Add(User.Name);
                mbuff_t.Add((int)User.HashKey);
                mbuff_t.Add((int)User.Level);
                if(mbuff_t.Lenght< 96)
                {
                    mbuff_t.Add(new byte[96 - mbuff_t.Lenght]); //format type nomal
                }

                /*
                byte[] rapping_buff = null;
                rapping_buff = array_add<byte>(rapping_buff);
                */
                return mScript.array_add<byte>(mbuff_t.ByteArray, buff_t);
            }
            public int UnRapping(ref mUser muser_buff)
            {
                //mUser return_muser= new mUser();

                if (this._buffer.Lenght < 96)//래핑 길이 비교 = 48*2
                {
                    return 100;
                }
                if (this._buffer.Read<String>() != "rapping")
                {
                    return 101;
                }
                long _format = this._buffer.Read<int>();
                switch (_format)
                {
                    case 0:
                        break;
                    default:
                        return 102;
                }
                long _buff_size = this._buffer.Read<int>();

                if (this._buffer.Lenght < 96 + _buff_size)//래핑 길이 비교 = 48*2
                {
                    return 103;
                }


                byte _buff_xor = this._buffer.Read<byte>();

                muser_buff.AppKey = this._buffer.Read<int>();
                muser_buff.ID = this._buffer.Read<int>();
                muser_buff.Name = this._buffer.Read<string>();
                muser_buff.HashKey = this._buffer.Read<int>();
                muser_buff.Level = this._buffer.Read<int>();
                muser_buff.EndPoint = this.EP;
                this._buffer.Index = 96;

                this._buffer.Delete(0, this._buffer.Index);

                if (this._buffer.XOR != _buff_xor)//xor비교
                {
                    return 104;
                }

                return 0;
            }
            public static mMessage None
            {
                get
                {
                    //return new mMessage(System.Net.IPAddress.None, 0);
                    return new mMessage(new IPEndPoint(System.Net.IPAddress.None, 0), mByteBuffer.None);
                }
            }
            public string IP
            {
                get
                {
                    //return this.EP.Address.ToString();
                    return ((IPEndPoint)this.EP).Address.ToString();
                }
                set
                {
                    this.EP = new IPEndPoint(System.Net.IPAddress.Parse(value),((IPEndPoint)this.EP).Port);
                    //this.EP.Address = System.Net.IPAddress.Parse(value);
                }
            }
            public Int32 Port
            {
                get
                {
                    //return this.EP.Port;
                    return ((IPEndPoint)this.EP).Port;
                }
                set
                {
                    this.EP = new IPEndPoint(((IPEndPoint)this.EP).Address, Math.Min(Math.Max(value, 0), 65535));
                    //((IPEndPoint)this.EP).Port= value;
                    //this.EP.Port = value;
                }
            }
        }

        public struct mUser
        {
            public long HashKey;
            public String Name;
            public long AppKey;
            public System.Net.EndPoint EndPoint;
            public long ID;
            public long Ping_Time;
            public long Level;
            public long State;
            public mUser(long HashKey, String Name, long AppKey, System.Net.EndPoint EndPoint)
            {
                this.HashKey = HashKey;
                this.Name = Name;
                this.AppKey = AppKey;
                this.EndPoint = EndPoint;
                this.ID = 0;
                this.Ping_Time = 0;
                this.Level = 0;
                this.State = 0;

            }
            public static mUser None
            {
                get
                {
                    //return this.EP.Port;
                    return new mUser(0,"None",0,null);
                }
            }
            public static bool operator ==(mUser _User1, mUser _User2)
            {
                return ((_User1.HashKey == _User2.HashKey)
                    && (_User1.Name == _User2.Name)
                    && (_User1.AppKey == _User2.AppKey)
                    && (_User1.EndPoint == _User2.EndPoint)
                    && (_User1.Ping_Time == _User2.Ping_Time)
                    && (_User1.Level == _User2.Level)
                    && (_User1.State == _User2.State)
                    && (_User1.ID == _User2.ID));
            }
            public static bool operator !=(mUser _User1, mUser _User2)
            {
                return !((_User1.HashKey == _User2.HashKey)
                    && (_User1.Name == _User2.Name)
                    && (_User1.AppKey == _User2.AppKey)
                    && (_User1.EndPoint == _User2.EndPoint)
                    && (_User1.Ping_Time == _User2.Ping_Time)
                    && (_User1.Level == _User2.Level)
                    && (_User1.State == _User2.State)
                    && (_User1.ID == _User2.ID));
            }
        }
        public struct mCltList
        {
            public long ID;
            public System.Net.EndPoint EndPoint;
            public mCltList(long ID, System.Net.EndPoint EndPoint)
            {
                this.EndPoint = EndPoint;
                this.ID = ID;
            }
        }
        public class Server
        {
            //public System.Net.IPEndPoint EP;
            private Int32 _port;
            private long Message_index = 0;
            private long Message_end = 0;
            private long Message_max_size = 1024;
            public mMessage[] Message = new mMessage[1024];
            //public byte[] _buffer = null;
            public List<mUser> UserList = new List<mUser>();
            //public List<mCltList> ClientList = new List<mCltList>();
            public long AppKey = 0;
            //private long ClientList_index_num = 0;
            private long ClientList_max = 0;
            private bool bind = false;
            private long[] new_user_num= new long[2];
            private Thread va_user_check_loop;
            public System.Net.Sockets.Socket Socket;
            public System.Net.Sockets.AddressFamily NetworkType;
            public System.Net.Sockets.ProtocolType ProtocolType;
            public System.Net.Sockets.SocketType SocketType;
            //private Thread ReceiveThread;
            public Server(mNetworkType NetworkType, mProtocolType ProtocolType, Int32 Port, long ClientList_max)
            {
                this._port = Port;
                //this.EP= new System.Net.IPEndPoint(System.Net.IPAddress.None, Port);
                if (ProtocolType == mProtocolType.TCP)
                {
                    this.SocketType = System.Net.Sockets.SocketType.Stream;
                    this.ProtocolType = System.Net.Sockets.ProtocolType.Tcp;
                }
                else
                {
                    this.SocketType = System.Net.Sockets.SocketType.Dgram;
                    this.ProtocolType = System.Net.Sockets.ProtocolType.Udp;
                }
                if (NetworkType == mNetworkType.IPV6)
                {
                    this.NetworkType = System.Net.Sockets.AddressFamily.InterNetworkV6;
                }
                else
                {
                    this.NetworkType = System.Net.Sockets.AddressFamily.InterNetwork;
                }
                this.Socket = new System.Net.Sockets.Socket(this.NetworkType, this.SocketType, this.ProtocolType);
                /*
                if (NetworkType == mNetworkType.IPV6)
                {
                    this.Socket.Bind(new System.Net.IPEndPoint(System.Net.IPAddress.IPv6Any, this._port));//모든 아이피에 연결해줌 0.0.0.0이 그것
                }
                else
                {
                    this.Socket.Bind(new System.Net.IPEndPoint(System.Net.IPAddress.Parse("0.0.0.0"), this._port));//모든 아이피에 연결해줌 0.0.0.0이 그것
                }
                */
                //this.Message = null;
                //this._buffer = null;
                //this.ClientList = null;
                //this.ClientList_index_num = 0;
                this.ClientList_max = ClientList_max;
                //this.ReceiveThread = new Thread(this.sc_receive);
                //this.ReceiveThread = new Thread(ReceiveThread);
                
            }
            public Server(System.Net.Sockets.AddressFamily NetworkType, System.Net.Sockets.SocketType SocketType,
                System.Net.Sockets.ProtocolType ProtocolType, Int32 Port, long ClientList_max, ThreadStart ReceiveThread)
            {
                this.NetworkType = NetworkType;
                this.SocketType = SocketType;
                this.ProtocolType = ProtocolType;
                this._port = Port;
                this.Socket = new System.Net.Sockets.Socket(this.NetworkType, this.SocketType, this.ProtocolType);
                //this.Message = null;
                //this._buffer = null;
                //this.ClientList = null;
                //this.ClientList_index_num = 0;
                this.ClientList_max = ClientList_max;
                //this.ReceiveThread = new Thread(this.sc_receive);
                //this.ReceiveThread = new Thread(ReceiveThread);
            }
            public void Bind()
            {
                if(bind==false)
                { 
                    if (this.NetworkType == System.Net.Sockets.AddressFamily.InterNetworkV6)
                    {
                        this.Socket.Bind(new System.Net.IPEndPoint(System.Net.IPAddress.IPv6Any, this._port));//모든 아이피에 연결해줌 0.0.0.0이 그것
                    }
                    else
                    {
                        this.Socket.Bind(new System.Net.IPEndPoint(System.Net.IPAddress.Any, this._port));//모든 아이피에 연결해줌 0.0.0.0이 그것
                        //this.Socket.Bind(new System.Net.IPEndPoint(System.Net.IPAddress.Parse("0.0.0.0"), this._port));//모든 아이피에 연결해줌 0.0.0.0이 그것
                    }
                    va_user_check_loop = new Thread(user_check_loop);
                    va_user_check_loop.Start();
                    bind = true;
                }
            }
            private void user_check_loop()
            {
                lock(new_user_num)
                { 
                    new_user_num[1] = new_user_num[0];
                    new_user_num[0] = 0;
                }
                Thread.Sleep(30*60*1000);//30 min
            }
            public void Send(byte[] send_buffer, long User_number)
            {
                if (User_number >= 0)
                {
                    if (User_number < this.UserList.Count)
                    {
                        this.Socket.SendTo(send_buffer, this.UserList[(int)User_number].EndPoint);
                    }
                }
            }
            public void Send(mMessage _message)
            {
                this.Socket.SendTo(_message._buffer.ByteArray, _message.EP);
            }
            public void Send(byte[] send_buffer, EndPoint EP)
            {
                this.Socket.SendTo(send_buffer, EP);
            }
            /*
            public void Send(byte[] send_buffer, long client_number)
            {
                if(client_number >= 0) 
                {
                    if (client_number < this.ClientList.Count)
                    {
                        this.Socket.SendTo(send_buffer, this.UserList[(int)this.ClientList[(int)client_number].ID].EndPoint);
                    }
                }
            }
            */
            public void Close()
            {
                //this.ReceiveThread.Abort();
                if(bind)
                {
                    this.va_user_check_loop.Abort();
                }
                this.Socket.Close();
            }
            /*
            private void sc_receive()
            {
                System.Net.EndPoint receive_ep = new System.Net.IPEndPoint(System.Net.IPAddress.None, 0);
                int receive_bytes_size = 1024;
                byte[] receive_bytes = new byte[receive_bytes_size];
                byte[] ping_bytes = new byte[] {50,111,116,107};

                int receive_size = 0;

                while (true)
                {
                    try
                    {
                        receive_size = Socket.ReceiveFrom(receive_bytes, ref receive_ep);
                        if (receive_size > 0)
                        {
                            if (receive_buff_size == 0)
                            {
                                for (int i = 0; i < receive_size; i++)
                                {
                                    receive_buff[i] = receive_bytes[i];
                                }
                                receive_buff_size = receive_size;
                            }

                        }
                        Socket.SendTo(ping_bytes, receive_ep);
                    }
                    catch
                    {
                        if (receive_bytes_size < 65507)//UDP송수신한계65507, TCP는 65535인듯.
                        {
                            receive_bytes_size = Math.Min(65507, receive_bytes_size * 2);

                        }
                        receive_bytes = new byte[receive_bytes_size];
                    }
                }
            }
            public void Delete(long offset)
            {
                this.Delete(offset, 1);
            }
            public void Delete(long offset, long _Length)
            {
                //offset is 0 ~ (_array.length - 1))
                if ((_Length <= 0) || (ClientList == null))
                {
                    return;
                }
                if (((offset >= 0) && ((offset + _Length) <= ClientList_index_num)) == false)//삭제위치가 배열크기를 벗어날경우
                {
                    return;
                }
                for (long i = offset; i < ClientList_index_num - _Length; i++) //입력받은 값을 넣는다
                {
                    this.ClientList[i] = this.ClientList[i + _Length];
                }
                ClientList_index_num -= _Length;
            }
            public void DeleteHS(long offset)
            {
                this.DeleteHS(offset, 1);
            }
            public void DeleteHS(long offset, long _Length)
            {
                //offset is 0 ~ (_array.length - 1))
                if ((_Length <= 0) || (ClientList == null))
                {
                    return;
                }
                if (((offset >= 0) && ((offset + _Length) <= ClientList_index_num)) == false)//삭제위치가 배열크기를 벗어날경우
                {
                    return;
                }
                for (long i = 0; i < _Length; i++) //입력받은 값을 넣는다
                {
                    this.ClientList[offset + i] = this.ClientList[ClientList_index_num - 1 - i];
                }
                ClientList_index_num -= _Length;
            }
            */

            public int AddMessage(EndPoint EP, params byte[] _buffer)
            {

                if (Message_index >= ((Message_end + 1) % Message_max_size))
                {
                    return 100;
                }
                this.Message[Message_index].EP = EP;
                this.Message[Message_index]._buffer.Add(_buffer);
                Message_end = (Message_end + 1) % Message_max_size;
                return 0;
            }
            public int ReadMessage(ref mMessage message_buff)
            {
                if (Message_index == Message_end)
                {
                    return 100;
                }
                message_buff._buffer.Delete();
                message_buff._buffer.Add((byte[])this.Message[Message_index]._buffer);
                message_buff.EP =this.Message[Message_index].EP;
                DeleteMessage();
                return 0;
            }
            public void DeleteMessage()
            {
                if (Message_index == Message_end)
                {
                    Message_index = 0;
                    Message_end = 0;
                    return;
                }
                this.Message[Message_index]._buffer.Delete();
                this.Message_index++;
                this.Message_index = this.Message_index % this.Message_max_size;
                if (Message_index == Message_end)
                {
                    Message_index = 0;
                    Message_end = 0;
                }
            }
            /*
            public int ClientAdd(mUser _user)
            {
                if (this.AppKey != 0)
                {
                    if (this.AppKey != _user.AppKey)
                    {
                        return 100;
                    }
                }
                int id = (int)_user.ID;
                if (id <= 0)
                {
                    state를 보내서 확인을 한다
                    mUser input = new mUser(_user.HashKey, _user.Name, _user.AppKey, _user.EndPoint);
                    this.ClientList.Add(input);
                    this.UserList.Add(input);
                    return 0;
                }
                state를 보내서 비교후 삭제하게 한다
                return 101;
            }
            */
            public int UserAdd(mUser _user)
            {
                if (this.AppKey != 0)
                {
                    if (this.AppKey != _user.AppKey)
                    {
                        return 100;
                    }
                }
                int id = (int)_user.ID;
                if (id <= 0)
                {
                    long check_num=0;
                    lock (new_user_num)
                    {
                        check_num = new_user_num[0] + new_user_num[1];
                    }
                    if(UserList.Count > 48)
                    {
                        check_num = UserList.Count;
                    }
                    else
                    {
                        check_num = mScript.median(48, check_num, UserList.Count);
                    }
                    check_num = UserList.Count- check_num;
                    for (int i = UserList.Count-1; i>= check_num; i--)
                    {
                        if(UserList[i].EndPoint== _user.EndPoint)
                        {
                            return 104;
                        }
                    }
                    mUser input = new mUser(_user.HashKey, _user.Name, _user.AppKey, _user.EndPoint);
                    if(UserList.Count==0)
                    {
                        this.UserList.Add(new mUser());
                    }
                    this.UserList.Add(input);
                    lock (new_user_num)
                    {
                        new_user_num[0]++;
                    }
                    return 0;
                }
                if (id < this.UserList.Count)
                {
                    if (this.UserList[id].Name != _user.Name)
                    {
                        return 102;
                    }
                    if (this.UserList[id].HashKey != _user.HashKey)
                    {
                        return 103;
                    }
                    if (this.UserList[id].EndPoint != _user.EndPoint)
                    {
                        /*
                        mUser input = new mUser(
                            this.ClientList[id].HashKey, 
                            this.ClientList[id].Name, 
                            this.ClientList[id].AppKey,
                            _user.EndPoint);
                        input.Level = this.ClientList[id].Level;
                        input.Ping_Time = this.ClientList[id].Ping_Time;
                        input.State = this.ClientList[id].State;
                        */
                        mUser input = this.UserList[id];
                        input.EndPoint = _user.EndPoint;
                        this.UserList[id]=input;
                        return 2;
                    }

                    return 1;
                }
                return 101;
                /*
                if (Message_index >= ((Message_end + 1) % Message_max_size))
                {
                    return -1;
                }
                this.Message[Message_index].EP = EP;
                this.Message[Message_index]._buffer.Add(_buffer);
                Message_index = (Message_index + 1) % Message_max_size;
                return 0;
                */
            }
            /*
            public void Add(params mMessage[] MessageArray)
            {
                if (MessageArray == null)
                {
                    return;
                }
                if (Message_index >= Message_max_size)
                {
                    return;
                }
                if (this.Message == null)
                {
                    this.Message = MessageArray;
                    return;
                }
                if (this.Message.LongLength < Math.Min(Message_max, Message_index + MessageArray.LongLength))
                {
                    mMessage[] ar_t = new mMessage[Math.Min(Message_max, (Message_index + MessageArray.LongLength) * 2)];//임시생성
                    for (long i = 0; i < Message_index; i++)//인덱스 개수만큼 복제.
                    {
                        ar_t[i] = this.Message[i];
                    }
                    this.Message = ar_t;
                }
                for (long i = 0; i < MessageArray.LongLength; i++) //입력받은 값을 넣는다
                {
                    this.Message[Message_index] = MessageArray[i];
                    Message_index++;
                    if (Message_index >= Message_max)
                    {
                        return;
                    }
                }
            }
            public void Add(params mUser[] UserArray)
            {
                if (UserArray == null)
                {
                    return;
                }
                if (ClientList_index_num >= ClientList_max)
                {
                    return;
                }
                if (this.ClientList == null)
                {
                    this.ClientList = UserArray;
                    return;
                }
                if (this.ClientList.LongLength < Math.Min(ClientList_max, ClientList_index_num + UserArray.LongLength))
                {
                    mUser[] ar_t = new mUser[Math.Min(ClientList_max, (ClientList_index_num + UserArray.LongLength) * 2)];//임시생성
                    for (long i = 0; i < ClientList_index_num; i++)//인덱스 개수만큼 복제.
                    {
                        ar_t[i] = this.ClientList[i];
                    }
                    this.ClientList = ar_t;
                }
                for (long i = 0; i < UserArray.LongLength; i++) //입력받은 값을 넣는다
                {
                    this.ClientList[ClientList_index_num] = UserArray[i];
                    ClientList_index_num++;
                    if (ClientList_index_num >= ClientList_max)
                    {
                        return;
                    }
                }
            }
            */
            public Int32 Port
            {
                get
                {
                    return this._port;
                }
                set
                {
                    if(this.bind == false)
                    {
                        this._port = Math.Min(Math.Max(value, 0), 65535);
                    }
                    //this.Socket.Bind(new System.Net.IPEndPoint(System.Net.IPAddress.Any, value));
                }
            }
            /*
            public string StringBuffer
            {
                get
                {
                    return Encoding.UTF8.GetString(this._buffer);
                }
                set
                {
                    this._buffer = Encoding.UTF8.GetBytes(value);
                }
            }
            */
            /*
            public long ClientListLength
            {
                get
                {
                    return this.ClientList.Count;
                }
            }
            public long ClientListMaxNumber
            {
                get
                {
                    return this.ClientList_max;
                }
                set
                {
                    lock (ClientList)
                    {
                        this.ClientList_max = Math.Max(0, value);
                        if (this.ClientList_index_num > ClientList_max)
                        {
                            this.ClientList_index_num = ClientList_max;
                            /*
                            if ((ClientList != null) && (ClientList.Length > ClientList_max))
                            {
                                for (int i = ClientList_max; i < ClientList.Length; i++)
                                {

                                }

                            }
                        }
                    }
                }
            }
            */
        }

        public static IPAddress get_my_ip()
        {

            foreach (System.Net.IPAddress ip_t in get_ip())
            {
                if (ip_t.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                {
                    return ip_t;
                }
            }
            return System.Net.IPAddress.None;
        }
        public static IPAddress[] get_ip()
        {
            return get_ip(Dns.GetHostName());
        }
        public static IPAddress[] get_ip(string HostName)
        {
            IPAddress[] _return = null;
            IPHostEntry entry = Dns.GetHostEntry(HostName);
            foreach (IPAddress _ip in entry.AddressList)
            {
                _return = mScript.array_add<IPAddress>(_return, _ip);
            }
            return _return;
        }
        
    }

    public static class mMouse
    {
        [DllImport("User32.dll")]
        public static extern int SetCursorPos(int x, int y);
        [DllImport("User32.dll")]
        public static extern int GetCursorPos(ref Point pos);

        [DllImport("user32.dll")] // 마우스 입력 
        static extern void mouse_event(uint dwFlags, uint dx, uint dy, int dwData, int dwExtraInfo);

        [System.Runtime.InteropServices.DllImport("User32.dll")] //마우스 상태
        public static extern int GetKeyboardState(ref byte[] pbKeyState);

        [DllImport("User32.dll")]
        public static extern short GetKeyState(int nVirtualKey);

        [DllImport("user32.dll")]
        static extern void keybd_event(byte vk, byte scan, int flags, int extrainfo);

        /*
        
            const byte AltKey = 18;
            const int KEYUP = 0x0002;    
            int Info=0;
            keybd_event(AltKey, 0, 0, ref Info);   // ALT key 다운
            keybd_event(AltKey, 0, KEYUP, ref Info);  // ALT key 업
        */
        //[System.Runtime.InteropServices.DllImport("user32.dll")] //마우스 상태
        //[return: MarshalAs(UnmanagedType.Bool)]
        //public static extern bool GetKeyboardState(byte[] pbKeyState);

        #region mouse_flag
        private const uint
            Absolute = 0x8000,
            LeftDown = 0x0002,
            LeftUp = 0x0004,
            MiddleDown = 0x0020,
            MiddleUp = 0x0040,
            Move = 0x0001,
            RightDown = 0x0008,
            RightUp = 0x0010,
            Wheel = 0x0800,
            XDown = 0x0080,
            XUp = 0x0100,
            HWheel = 0x1000;
        #endregion

        #region mouse_state
        private const byte
            Left_botton = 1,
            middle_botton = 4,
            right_botton = 2;
        #endregion

        private static byte[] key_state = new byte[256];
        //public static mVec2 pos;

        public static int x
        {
            get
            {
                Point _pos_t = new Point();
                GetCursorPos(ref _pos_t);
                return _pos_t.X;
            }
            set
            {
                SetCursorPos(value, y);
            }
        }
        public static int y
        {
            get
            {
                Point _pos_t = new Point();
                GetCursorPos(ref _pos_t);
                return _pos_t.Y;
            }
            set
            {
                SetCursorPos(x, value);
            }
        }
        public static mVec2 pos
        {
            get
            {
                Point _pos_t = new Point();
                GetCursorPos(ref _pos_t);
                return new mVec2(_pos_t.X, _pos_t.Y);
            }
            set
            {
                SetCursorPos((int)value.x, (int)value.y);
            }
        }

        public static bool left
        {
            get
            {
                return (GetKeyState(Left_botton) & 0x80) != 0;
            }
            set
            {
                //uint _flag_t;
                if (value)
                {
                    //keybd_event(0x01, 0, 0,0);   // ALT key 다운
                    mouse_event(LeftDown, 0, 0, 0, 0);
                }
                else
                {
                    //keybd_event(0x01, 0, 0x0002, 0);   // ALT key 다운
                    mouse_event(LeftUp, 0, 0, 0, 0);
                }
            }
        }
    }

    public static class mKey
    {
        [DllImport("User32.dll")]
        public static extern short GetKeyState(int nVirtualKey);

        [System.Runtime.InteropServices.DllImport("user32.dll")] //키보드 상태
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern int GetKeyboardState(byte[] pbKeyState);

        [DllImport("user32.dll")]
        static extern void keybd_event(byte vk, byte scan, int flags, int extrainfo);

        private static bool hangle_toggle = false;

        #region key_state
        private const int
            key_down = 0x0000,
            key_up = 0x0002;
        #endregion

        #region kr_key_index_array
        private static string[]
            kr_index_first =
            {
                "ㄱ","ㄲ","ㄴ","ㄷ","ㄸ","ㄹ","ㅁ","ㅂ","ㅃ","ㅅ",
                "ㅆ","ㅇ","ㅈ","ㅉ","ㅊ","ㅋ","ㅌ","ㅍ","ㅎ"
            },
            kr_index_second =
            {
                "ㅏ","ㅐ","ㅑ","ㅒ","ㅓ","ㅔ","ㅕ","ㅖ","ㅗ","ㅗㅏ",
                "ㅗㅐ","ㅗㅣ","ㅛ","ㅜ","ㅜㅓ","ㅜㅔ","ㅜㅣ","ㅠ","ㅡ","ㅡㅣ",
                "ㅣ"
            },
            kr_index_third =
            {
                "","ㄱ","ㄲ","ㄱㅅ","ㄴ","ㄴㅈ","ㄴㅎ","ㄷ","ㄹ","ㄹㄱ",
                "ㄹㅁ","ㄹㅂ","ㄹㅅ","ㄹㅌ","ㄹㅍ","ㄹㅎ","ㅁ","ㅂ","ㅂㅅ","ㅅ",
                "ㅆ","ㅇ","ㅈ","ㅊ","ㅋ","ㅌ","ㅍ","ㅎ"
            };
        #endregion


        #region VirtualKey
        public static byte


            vk_backspace = 0x08,
            vk_back = vk_backspace,  //BACKSPACE key

            vk_return = 0x0D,  //ENTER key
            vk_enter = vk_return,  //ENTER key

            vk_shift = 0x10,  //SHIFT key
            vk_control = 0x11,  //CTRL key
            vk_ctrl = vk_control,  //CTRL key


            vk_capital = 0x14,  //CAPS LOCK key
            vk_cap = vk_capital,  //CAPS LOCK key

            vk_hangul = 0x15, //hangul

            vk_escape = 0x1B,  //ESC key
            vk_esc = vk_escape,  //ESC key

            vk_space = 0x20,  //SPACEBAR


            vk_left = 0x25,  //LEFT ARROW key
            vk_le = vk_left,  //LEFT ARROW key
            vk_up = 0x26,  //UP ARROW key
            vk_right = 0x27,  //RIGHT ARROW key
            vk_ri = vk_right,  //RIGHT ARROW key
            vk_down = 0x28,  //DOWN ARROW key
            vk_do = vk_down,  //DOWN ARROW key




            vk_0 = 0x30,  //0 key
            vk_1 = 0x31,  //1 key
            vk_2 = 0x32,  //2 key
            vk_3 = 0x33,  //3 key
            vk_4 = 0x34,  //4 key
            vk_5 = 0x35,  //5 key
            vk_6 = 0x36,  //6 key
            vk_7 = 0x37,  //7 key
            vk_8 = 0x38,  //8 key
            vk_9 = 0x39,  //9 key
            vk_a = 0x41,  //A key
            vk_b = 0x42,  //B key
            vk_c = 0x43,  //C key
            vk_d = 0x44,  //D key
            vk_e = 0x45,  //E key
            vk_f = 0x46,  //F key
            vk_g = 0x47,  //G key
            vk_h = 0x48,  //H key
            vk_i = 0x49,  //I key
            vk_j = 0x4A,  //J key
            vk_k = 0x4B,  //K key
            vk_l = 0x4C,  //L key
            vk_m = 0x4D,  //M key
            vk_n = 0x4E,  //N key
            vk_o = 0x4F,  //O key
            vk_p = 0x50,  //P key
            vk_q = 0x51,  //Q key
            vk_r = 0x52,  //R key
            vk_s = 0x53,  //S key
            vk_t = 0x54,  //T key
            vk_u = 0x55,  //U key
            vk_v = 0x56,  //V key
            vk_w = 0x57,  //W key
            vk_x = 0x58,  //X key
            vk_y = 0x59,  //Y key
            vk_z = 0x5A,  //Z key




            vk_multiply = 0x6A,  // *
            vk_add = 0x6B,  // +
            vk_separator = 0x6C,  //Separator key
            vk_subtract = 0x6D,  // - 
            vk_decimal = 0x6E,  //.
            vk_divide = 0x6F,  // / key


            vk_oem_1 = 0xBA,  // ; :

            vk_oem_plus = 0xBB,  // = +
            vk_oem_comma = 0xBC,  // , <
            vk_oem_minus = 0xBD,  // - _
            vk_oem_period = 0xBE,  // . >

            vk_oem_2 = 0xBF,  // / ?
            vk_oem_3 = 0xC0,  // ` ~



            vk_oem_4 = 0xDB,  // [ {
            vk_oem_5 = 0xDC,  // \ |
            vk_oem_6 = 0xDD,  // ] }


            vk_oem_7 = 0xDE,  // ' "
            vk_oem_8 = 0xDf  //




        ;
        #endregion

        #region VirtualKey2
        public static int VK_LBUTTON = 0x01,  //Left mouse button
            VK_RBUTTON = 0x02,  //Right mouse button
            VK_CANCEL = 0x03,  //Control-break processing
            VK_MBUTTON = 0x04,  //Middle mouse button (three-button mouse)
            VK_BACK = 0x08,  //BACKSPACE key
            VK_TAB = 0x09,  //TAB key
            VK_CLEAR = 0x0C,  //CLEAR key
            VK_RETURN = 0x0D,  //ENTER key
            VK_SHIFT = 0x10,  //SHIFT key
            VK_CONTROL = 0x11,  //CTRL key
            VK_MENU = 0x12,  //ALT key
            VK_PAUSE = 0x13,  //PAUSE key
            VK_CAPITAL = 0x14,  //CAPS LOCK key
            VK_HANGUL = 0x15,
            VK_ESCAPE = 0x1B,  //ESC key
            VK_SPACE = 0x20,  //SPACEBAR
            VK_PRIOR = 0x21,  //PAGE UP key
            VK_NEXT = 0x22,  //PAGE DOWN key
            VK_END = 0x23,  //END key
            VK_HOME = 0x24,  //HOME key
            VK_LEFT = 0x25,  //LEFT ARROW key
            VK_UP = 0x26,  //UP ARROW key
            VK_RIGHT = 0x27,  //RIGHT ARROW key
            VK_DOWN = 0x28,  //DOWN ARROW key
            VK_SELECT = 0x29,  //SELECT key
            VK_PRINT = 0x2A,  //PRINT key
            VK_EXECUTE = 0x2B,  //EXECUTE key
            VK_SNAPSHOT = 0x2C,  //PRINT SCREEN key
            VK_INSERT = 0x2D,  //INS key
            VK_DELETE = 0x2E,  //DEL key
            VK_HELP = 0x2F,  //HELP key
            VK_0 = 0x30,  //0 key
            VK_1 = 0x31,  //1 key
            VK_2 = 0x32,  //2 key
            VK_3 = 0x33,  //3 key
            VK_4 = 0x34,  //4 key
            VK_5 = 0x35,  //5 key
            VK_6 = 0x36,  //6 key
            VK_7 = 0x37,  //7 key
            VK_8 = 0x38,  //8 key
            VK_9 = 0x39,  //9 key
            VK_A = 0x41,  //A key
            VK_B = 0x42,  //B key
            VK_C = 0x43,  //C key
            VK_D = 0x44,  //D key
            VK_E = 0x45,  //E key
            VK_F = 0x46,  //F key
            VK_G = 0x47,  //G key
            VK_H = 0x48,  //H key
            VK_I = 0x49,  //I key
            VK_J = 0x4A,  //J key
            VK_K = 0x4B,  //K key
            VK_L = 0x4C,  //L key
            VK_M = 0x4D,  //M key
            VK_N = 0x4E,  //N key
            VK_O = 0x4F,  //O key
            VK_P = 0x50,  //P key
            VK_Q = 0x51,  //Q key
            VK_R = 0x52,  //R key
            VK_S = 0x53,  //S key
            VK_T = 0x54,  //T key
            VK_U = 0x55,  //U key
            VK_V = 0x56,  //V key
            VK_W = 0x57,  //W key
            VK_X = 0x58,  //X key
            VK_Y = 0x59,  //Y key
            VK_Z = 0x5A,  //Z key
            VK_NUMPAD0 = 0x60,  //Numeric keypad 0 key
            VK_NUMPAD1 = 0x61,  //Numeric keypad 1 key
            VK_NUMPAD2 = 0x62,  //Numeric keypad 2 key
            VK_NUMPAD3 = 0x63,  //Numeric keypad 3 key
            VK_NUMPAD4 = 0x64,  //Numeric keypad 4 key
            VK_NUMPAD5 = 0x65,  //Numeric keypad 5 key
            VK_NUMPAD6 = 0x66,  //Numeric keypad 6 key
            VK_NUMPAD7 = 0x67,  //Numeric keypad 7 key
            VK_NUMPAD8 = 0x68,  //Numeric keypad 8 key
            VK_NUMPAD9 = 0x69,  //Numeric keypad 9 key
            VK_SEPARATOR = 0x6C,  //Separator key
            VK_SUBTRACT = 0x6D,  //Subtract key
            VK_DECIMAL = 0x6E,  //Decimal key
            VK_DIVIDE = 0x6F,  //Divide key
            VK_F1 = 0x70,  //F1 key
            VK_F2 = 0x71,  //F2 key
            VK_F3 = 0x72,  //F3 key
            VK_F4 = 0x73,  //F4 key
            VK_F5 = 0x74,  //F5 key
            VK_F6 = 0x75,  //F6 key
            VK_F7 = 0x76,  //F7 key
            VK_F8 = 0x77,  //F8 key
            VK_F9 = 0x78,  //F9 key
            VK_F10 = 0x79,  //F10 key
            VK_F11 = 0x7A,  //F11 key
            VK_F12 = 0x7B,  //F12 key
            VK_SCROLL = 0x91,  //SCROLL LOCK key
            VK_LSHIFT = 0xA0,  //Left SHIFT key
            VK_RSHIFT = 0xA1,  //Right SHIFT key
            VK_LCONTROL = 0xA2,  //Left CONTROL key
            VK_RCONTROL = 0xA3,  //Right CONTROL key
            VK_LMENU = 0xA4,   //Left MENU key
            VK_RMENU = 0xA5,  //Right MENU key
            VK_PLAY = 0xFA,  //Play key
            VK_ZOOM = 0xFB //Zoom key
            ;
        #endregion

        private static byte[] key_state = new byte[256];

        public static bool enter
        {
            get
            {
                return keyboard_check(vk_enter);
            }
            set
            {
                if (value)
                {
                    keybd_event(vk_enter, 0, key_down, 0);
                }
                else
                {
                    keybd_event(vk_enter, 0, key_up, 0);
                }
            }
        }
        public static bool esc
        {
            get
            {
                return keyboard_check(vk_esc);
            }
            set
            {
                if (value)
                {
                    keybd_event(vk_esc, 0, key_down, 0);
                }
                else
                {
                    keybd_event(vk_esc, 0, key_up, 0);
                }
            }
        }
        public static bool shift
        {
            get
            {
                return keyboard_check(vk_shift);
            }
            set
            {
                if (value)
                {
                    keybd_event(vk_shift, 0, key_down, 0);
                }
                else
                {
                    keybd_event(vk_shift, 0, key_up, 0);
                }
            }
        }
        public static bool space
        {
            get
            {
                return keyboard_check(vk_space);
            }
            set
            {
                if (value)
                {
                    keybd_event(vk_space, 0, key_down, 0);
                }
                else
                {
                    keybd_event(vk_space, 0, key_up, 0);
                }
            }
        }
        public static bool back
        {
            get
            {
                return keyboard_check(vk_back);
            }
            set
            {
                if (value)
                {
                    keybd_event(vk_back, 0, key_down, 0);
                }
                else
                {
                    keybd_event(vk_back, 0, key_up, 0);
                }
            }
        }
        public static bool ctrl
        {
            get
            {
                return keyboard_check(vk_ctrl);
            }
            set
            {
                if (value)
                {
                    keybd_event(vk_ctrl, 0, key_down, 0);
                }
                else
                {
                    keybd_event(vk_ctrl, 0, key_up, 0);
                }
            }
        }
        public static bool hangul
        {
            get
            {
                return hangle_toggle;
            }
            set
            {
                if (value != hangul)
                {
                    keybd_event(vk_hangul, 0, key_down, 0);
                    keybd_event(vk_hangul, 0, key_up, 0);
                    hangle_toggle = value;
                }
            }
        }
        public static bool cap
        {
            get
            {
                return keyboard_check_toggle(vk_cap);
            }
            set
            {
                if (value != cap)
                {
                    keybd_event(vk_cap, 0, key_down, 0);
                    keybd_event(vk_cap, 0, key_up, 0);
                }
            }
        }
        public static bool key_check(int key)
        {
            return keyboard_check(key);
        }
        public static bool key_check_toggle(int key)
        {
            return keyboard_check_toggle(key);
        }
        public static bool keyboard_check_toggle(int key)
        {
            return (GetKeyState(key) & 0x0001) != 0;
            // GetKeyboardState(key_state);
        }
        public static bool keyboard_check(int key)
        {
            return (GetKeyState(key) & 0x8000) > 0;
            // GetKeyboardState(key_state);
        }
        public static void key_press(string _str)
        {

            byte[] by_keycode = convert_to_keycode(_str);
            bool[] bo_shift = convert_to_shift(_str);
            bool[] bo_hangul = convert_to_simple_and_if_kr(_str);



            for (int i = 0; i < by_keycode.Length; i++)
            {

                shift = bo_shift[i];
                if (hangul != bo_hangul[i])
                {
                    hangul = bo_hangul[i];
                    Thread.Sleep(200);
                }
                keybd_event(by_keycode[i], 0, key_down, 0);
                keybd_event(by_keycode[i], 0, key_up, 0);
            }
            shift = false;
            if (hangul != false)
            {
                space = true;
                space = false;

                back = true;
                back = false;

                hangul = false;
                Thread.Sleep(200);
            }
        }


        public static bool kr_exists(string _str)
        {
            bool[] bo_array = convert_to_if_kr(_str);
            for (int i = 0; i < bo_array.Length; i++)
            {
                if (bo_array[i])
                {
                    return true;
                }
            }
            return false;
        }
        public static bool[] convert_to_simple_and_if_kr(string _str)
        {
            return convert_to_if_kr(convert_to_simple_kr(_str));
        }
        public static bool[] convert_to_if_kr(string _str)
        {
            char[] _cha = _str.ToCharArray();
            bool[] _bool = new bool[_cha.Length];
            for (int i = 0; i < _cha.Length; i++)
            {
                _bool[i] = convert_to_if_kr(_cha[i]);
            }
            return _bool;
        }
        public static bool convert_to_if_kr(char _cha)
        {
            return ((_cha >= 0x1100) && (_cha <= 0x11FF))
                || ((_cha >= 0x3131) && (_cha <= 0x319E))
                || ((_cha >= 0xAC00) && (_cha <= 0xD7A3));
        }

        public static bool convert_to_if_completion_kr(char _cha)
        {
            return (_cha >= 0xAC00) && (_cha <= 0xD7A3);
        }

        public static byte[] convert_to_keycode(string _str)
        {

            char[] _cha = convert_to_simple_kr(_str).ToCharArray();


            byte[] _byte = new byte[_cha.Length];
            for (int i = 0; i < _cha.Length; i++)
            {
                _byte[i] = convert_to_keycode(_cha[i]);
            }
            return _byte;
        }
        public static byte convert_to_keycode(char _cha)
        {
            switch (_cha)
            {

                case '\n':
                    return vk_enter;

                case ';':
                case ':':
                    return vk_oem_1;
                case '/':
                case '?':
                    return vk_oem_2;
                case '`':
                case '~':
                    return vk_oem_3;
                case '[':
                case '{':
                    return vk_oem_4;
                case '\\':
                case '|':
                    return vk_oem_5;
                case ']':
                case '}':
                    return vk_oem_6;
                case '\'':
                case '"':
                    return vk_oem_7;
                case '=':
                case '+':
                    return vk_oem_plus;
                case '-':
                case '_':
                    return vk_oem_minus;
                case ',':
                case '<':
                    return vk_oem_comma;
                case '.':
                case '>':
                    return vk_oem_period;

                case ' ':
                    return vk_space;
                case '0':
                case ')':
                    return vk_0;
                case '1':
                case '!':
                    return vk_1;
                case '2':
                case '@':
                    return vk_2;
                case '3':
                case '#':
                    return vk_3;
                case '4':
                case '$':
                    return vk_4;
                case '5':
                case '%':
                    return vk_5;
                case '6':
                case '^':
                    return vk_6;
                case '7':
                case '&':
                    return vk_7;
                case '8':
                case '*':
                    return vk_8;
                case '9':
                case '(':
                    return vk_9;
                case 'a':
                case 'A':
                case 'ㅁ':
                    return vk_a;
                case 'b':
                case 'B':
                case 'ㅠ':
                    return vk_b;
                case 'c':
                case 'C':
                case 'ㅊ':
                    return vk_c;
                case 'd':
                case 'D':
                case 'ㅇ':
                    return vk_d;
                case 'e':
                case 'E':
                case 'ㄷ':
                case 'ㄸ':
                    return vk_e;
                case 'f':
                case 'F':
                case 'ㄹ':
                    return vk_f;
                case 'g':
                case 'G':
                case 'ㅎ':
                    return vk_g;
                case 'h':
                case 'H':
                case 'ㅗ':
                    return vk_h;
                case 'i':
                case 'I':
                case 'ㅑ':
                    return vk_i;
                case 'j':
                case 'J':
                case 'ㅓ':
                    return vk_j;
                case 'k':
                case 'K':
                case 'ㅏ':
                    return vk_k;
                case 'l':
                case 'L':
                case 'ㅣ':
                    return vk_l;
                case 'm':
                case 'M':
                case 'ㅡ':
                    return vk_m;
                case 'n':
                case 'N':
                case 'ㅜ':
                    return vk_n;
                case 'o':
                case 'O':
                case 'ㅐ':
                case 'ㅒ':
                    return vk_o;
                case 'p':
                case 'P':
                case 'ㅔ':
                case 'ㅖ':
                    return vk_p;
                case 'q':
                case 'Q':
                case 'ㅂ':
                case 'ㅃ':
                    return vk_q;
                case 'r':
                case 'R':
                case 'ㄱ':
                case 'ㄲ':
                    return vk_r;
                case 's':
                case 'S':
                case 'ㄴ':
                    return vk_s;
                case 't':
                case 'T':
                case 'ㅅ':
                case 'ㅆ':
                    return vk_t;
                case 'u':
                case 'U':
                case 'ㅕ':
                    return vk_u;
                case 'v':
                case 'V':
                case 'ㅍ':
                    return vk_v;
                case 'w':
                case 'W':
                case 'ㅈ':
                case 'ㅉ':
                    return vk_w;
                case 'x':
                case 'X':
                case 'ㅌ':
                    return vk_x;
                case 'y':
                case 'Y':
                case 'ㅛ':
                    return vk_y;
                case 'z':
                case 'Z':
                case 'ㅋ':
                    return vk_z;
            }
            return 0;
        }

        public static bool[] convert_to_shift(string _str)
        {

            char[] _cha = convert_to_simple_kr(_str).ToCharArray();

            bool[] _bool = new bool[_cha.Length];
            for (int i = 0; i < _cha.Length; i++)
            {
                _bool[i] = convert_to_shift(_cha[i]);
            }
            return _bool;
        }
        public static bool convert_to_shift(char _cha)
        {
            switch (_cha)
            {



                case '<':
                case '>':
                case '?':
                case '"':
                case ':':
                case '{':
                case '}':
                case '_':
                case '+':
                case '|':
                case '~':

                case ')':
                case '!':
                case '@':
                case '#':
                case '$':
                case '%':
                case '&':
                case '*':
                case '^':
                case '(':

                case 'A':
                case 'B':
                case 'C':
                case 'D':
                case 'E':
                case 'ㄸ':
                case 'F':
                case 'G':
                case 'H':
                case 'I':
                case 'J':
                case 'K':
                case 'L':
                case 'M':
                case 'N':
                case 'O':
                case 'ㅒ':
                case 'P':
                case 'ㅖ':
                case 'Q':
                case 'ㅃ':
                case 'R':
                case 'ㄲ':
                case 'S':
                case 'T':
                case 'ㅆ':
                case 'U':
                case 'V':
                case 'W':
                case 'ㅉ':
                case 'X':
                case 'Y':
                case 'Z':
                    return true;
            }
            return false;
        }

        public static string convert_to_simple_kr(string _str)
        {
            char[] _cha = _str.ToCharArray();

            string _str_t = "";
            for (int i = 0; i < _cha.Length; i++)
            {
                _str_t += convert_to_simple_kr(_cha[i]);
            }
            return _str_t;
        }
        public static string convert_to_simple_kr(char _cha)
        {
            string _str = "";
            if (!convert_to_if_completion_kr(_cha))
            {
                _str += _cha;
                return _str;
            }
            int c_number = _cha - 0xAC00;
            _str += kr_index_first[c_number / (28 * 21)];
            _str += kr_index_second[(c_number % (28 * 21)) / 28];
            _str += kr_index_third[c_number % 28];
            return _str;
        }

    }
    public class mScript
    {
        //Dir




        public static float pi = 3.14159265358979f;
        public static double do_pi = 3.1415926535897932384626433832795d;
        public static double do_pi_div_180 = (do_pi / 180d);
        public static double do_180_div_pi = (180d / do_pi);
        public static float pi_div_180 = (float)(do_pi_div_180);
        public static float _180_div_pi = (float)(do_180_div_pi);

        public static Bitmap screen_img = new Bitmap(SystemInformation.VirtualScreen.Width
                    , SystemInformation.VirtualScreen.Height
                    , PixelFormat.Format32bppArgb);

        public static Graphics graphics_screen_img = Graphics.FromImage(screen_img);

        public static System.Random mran_seed = new System.Random((Int32)DateTime.Now.Ticks);
        public static long time = DateTime.Now.Ticks;
        //((long)(DateTime.Now.Ticks/10000000)); is second

        #region VirtualKey
        public enum VKeys : int
        {
            VK_LBUTTON = 0x01,  //Left mouse button
            VK_RBUTTON = 0x02,  //Right mouse button
            VK_CANCEL = 0x03,  //Control-break processing
            VK_MBUTTON = 0x04,  //Middle mouse button (three-button mouse)
            VK_BACK = 0x08,  //BACKSPACE key
            VK_TAB = 0x09,  //TAB key
            VK_CLEAR = 0x0C,  //CLEAR key
            VK_RETURN = 0x0D,  //ENTER key
            VK_SHIFT = 0x10,  //SHIFT key
            VK_CONTROL = 0x11,  //CTRL key
            VK_MENU = 0x12,  //ALT key
            VK_PAUSE = 0x13,  //PAUSE key
            VK_CAPITAL = 0x14,  //CAPS LOCK key
            VK_HANGUL = 0x15,
            VK_ESCAPE = 0x1B,  //ESC key
            VK_SPACE = 0x20,  //SPACEBAR
            VK_PRIOR = 0x21,  //PAGE UP key
            VK_NEXT = 0x22,  //PAGE DOWN key
            VK_END = 0x23,  //END key
            VK_HOME = 0x24,  //HOME key
            VK_LEFT = 0x25,  //LEFT ARROW key
            VK_UP = 0x26,  //UP ARROW key
            VK_RIGHT = 0x27,  //RIGHT ARROW key
            VK_DOWN = 0x28,  //DOWN ARROW key
            VK_SELECT = 0x29,  //SELECT key
            VK_PRINT = 0x2A,  //PRINT key
            VK_EXECUTE = 0x2B,  //EXECUTE key
            VK_SNAPSHOT = 0x2C,  //PRINT SCREEN key
            VK_INSERT = 0x2D,  //INS key
            VK_DELETE = 0x2E,  //DEL key
            VK_HELP = 0x2F,  //HELP key
            VK_0 = 0x30,  //0 key
            VK_1 = 0x31,  //1 key
            VK_2 = 0x32,  //2 key
            VK_3 = 0x33,  //3 key
            VK_4 = 0x34,  //4 key
            VK_5 = 0x35,  //5 key
            VK_6 = 0x36,  //6 key
            VK_7 = 0x37,  //7 key
            VK_8 = 0x38,  //8 key
            VK_9 = 0x39,  //9 key
            VK_A = 0x41,  //A key
            VK_B = 0x42,  //B key
            VK_C = 0x43,  //C key
            VK_D = 0x44,  //D key
            VK_E = 0x45,  //E key
            VK_F = 0x46,  //F key
            VK_G = 0x47,  //G key
            VK_H = 0x48,  //H key
            VK_I = 0x49,  //I key
            VK_J = 0x4A,  //J key
            VK_K = 0x4B,  //K key
            VK_L = 0x4C,  //L key
            VK_M = 0x4D,  //M key
            VK_N = 0x4E,  //N key
            VK_O = 0x4F,  //O key
            VK_P = 0x50,  //P key
            VK_Q = 0x51,  //Q key
            VK_R = 0x52,  //R key
            VK_S = 0x53,  //S key
            VK_T = 0x54,  //T key
            VK_U = 0x55,  //U key
            VK_V = 0x56,  //V key
            VK_W = 0x57,  //W key
            VK_X = 0x58,  //X key
            VK_Y = 0x59,  //Y key
            VK_Z = 0x5A,  //Z key
            VK_NUMPAD0 = 0x60,  //Numeric keypad 0 key
            VK_NUMPAD1 = 0x61,  //Numeric keypad 1 key
            VK_NUMPAD2 = 0x62,  //Numeric keypad 2 key
            VK_NUMPAD3 = 0x63,  //Numeric keypad 3 key
            VK_NUMPAD4 = 0x64,  //Numeric keypad 4 key
            VK_NUMPAD5 = 0x65,  //Numeric keypad 5 key
            VK_NUMPAD6 = 0x66,  //Numeric keypad 6 key
            VK_NUMPAD7 = 0x67,  //Numeric keypad 7 key
            VK_NUMPAD8 = 0x68,  //Numeric keypad 8 key
            VK_NUMPAD9 = 0x69,  //Numeric keypad 9 key
            VK_SEPARATOR = 0x6C,  //Separator key
            VK_SUBTRACT = 0x6D,  //Subtract key
            VK_DECIMAL = 0x6E,  //Decimal key
            VK_DIVIDE = 0x6F,  //Divide key
            VK_F1 = 0x70,  //F1 key
            VK_F2 = 0x71,  //F2 key
            VK_F3 = 0x72,  //F3 key
            VK_F4 = 0x73,  //F4 key
            VK_F5 = 0x74,  //F5 key
            VK_F6 = 0x75,  //F6 key
            VK_F7 = 0x76,  //F7 key
            VK_F8 = 0x77,  //F8 key
            VK_F9 = 0x78,  //F9 key
            VK_F10 = 0x79,  //F10 key
            VK_F11 = 0x7A,  //F11 key
            VK_F12 = 0x7B,  //F12 key
            VK_SCROLL = 0x91,  //SCROLL LOCK key
            VK_LSHIFT = 0xA0,  //Left SHIFT key
            VK_RSHIFT = 0xA1,  //Right SHIFT key
            VK_LCONTROL = 0xA2,  //Left CONTROL key
            VK_RCONTROL = 0xA3,  //Right CONTROL key
            VK_LMENU = 0xA4,   //Left MENU key
            VK_RMENU = 0xA5,  //Right MENU key
            VK_PLAY = 0xFA,  //Play key
            VK_ZOOM = 0xFB, //Zoom key
        }
        #endregion

        





        public static float lengthdir_x(float _Len, float _Dir)
        {
            return len_x(_Len, _Dir);
        }
        public static float lengthdir_y(float _Len, float _Dir)
        {
            return len_x(_Len, _Dir);
        }
        public static float len_x(float _Dir)
        {
            return (float)len_x(1d, (double)_Dir);
        }
        public static float len_x(float _Len, float _Dir)
        {
            return (float)len_x((double)_Len, (double)_Dir);
        }
        public static double len_x(double _Len, double _Dir)
        {
            _Dir = d_set(_Dir);
            if (_Dir == 0d)
            {
                return _Len;
            }
            if ((_Dir == 90d) || (_Dir == 270d))
            {
                return 0d;
            }
            if (_Dir == 180d)
            {
                return -_Len;
            }
            return _Len * Math.Cos(_Dir * do_pi_div_180);
        }
        public static float len_y(float _Dir)
        {
            return (float)len_y(1d, (double)_Dir);
        }
        public static float len_y(float _Len, float _Dir)
        {
            return (float)len_y((double)_Len, (double)_Dir);
        }
        public static double len_y(double _Len, double _Dir)
        {
            _Dir = d_set(_Dir);
            if (_Dir == 90d)
            {
                return _Len;
            }
            if ((_Dir == 0d) || (_Dir == 180d))
            {
                return 0d;
            }
            if (_Dir == 270d)
            {
                return -_Len;
            }
            return _Len * Math.Sin(_Dir * do_pi_div_180);
        }
        public static mVec2 len_vec(float _Dir)
        {
            return len_vec(1f, _Dir);
        }
        public static mVec2 len_vec(float _Len, float _Dir)
        {
            return new mVec2(len_x(_Len, _Dir), len_y(_Len, _Dir));
        }
        public static mVec2 len_vec(float _x, float _y, float _Dir)
        {
            float _len = p_dis(_x, _y);
            return len_vec(_len, p_dir(_x, _y) - _Dir);
        }
        public static mVec2 len_vec(mVec2 _Len, float _Dir)
        {
            return len_vec(_Len.x, _Len.y, _Dir);
        }


        public static mVec2 len_vec_rel(mVec2 _Vec, float _Dir)
        {
            return len_vec_rel(_Vec.x, _Vec.y, _Dir);
        }
        public static mVec2 len_vec_rel(float _X, float _Y, float _Dir)
        {
            return len_vec(_X, _Y, -_Dir);
        }

        public static float point_distance_3d(float _x, float _y, float _z)
        {
            return p_dis(_x, _y, _z);
        }
        public static float point_distance(float _x, float _y, float _z)
        {
            return p_dis(_x, _y, _z);
        }
        public static float point_distance(float _x, float _y)
        {
            return p_dis(_x, _y);
        }

        public static float p_dis(float _x, float _y)
        {
            return (float)p_dis((double)_x, (double)_y);
        }
        public static double p_dis(double _x, double _y)
        {
            return Math.Sqrt((_x * _x) + (_y * _y));
        }
        public static float p_dis(mVec2 _vec)
        {
            return p_dis(_vec.x, _vec.y);
        }
        public static double p_dis(double _x, double _y, double _z)
        {
            return Math.Sqrt((_x * _x) + (_y * _y) + (_z * _z));
        }
        public static float p_dis(float _x, float _y, float _z)
        {
            return (float)p_dis((double)_x, (double)_y, (double)_z);
        }








        public static float point_direction(float _x, float _y)
        {
            return p_dir(_x, _y);
        }
        public static float point_direction(float _x1, float _y1, float _x2, float _y2)
        {
            return p_dir(_x1, _y1, _x2, _y2);
        }
        public static float p_dir_win(mVec2 _pos)
        {
            return p_dir_win(_pos.x, _pos.y);
        }
        public static float p_dir_win(float x, float y)
        {
            return p_dir_origin(x, -y);
        }
        public static float p_dir(mVec2 _pos)
        {
            return p_dir(_pos.x, _pos.y);
        }
        public static float p_dir(float _x1, float _y1, float _x2, float _y2)
        {
            return p_dir(_x2 - _x1, _y2 - _y1);
        }
        public static float p_dir(float _x, float _y)
        {
            return p_dir_origin(_x, _y);
        }
        public static float p_dir_origin(float _x, float _y)
        {
            return (float)p_dir_origin((double)_x, (double)_y);
        }
        public static double p_dir_origin(double _x, double _y)
        {
            if (_x == 0d)
            {
                if (_y < 0d)
                {
                    return 270d;
                }
                if (_y == 0d)
                {
                    return 0d;
                }
                return 90d;
            }
            if (_y == 0d)
            {
                if (_x < 0d)
                {
                    return 180d;
                }
                return 0d;
            }
            if (_x < 0d)
            {
                if (_y < 0d)
                {
                    return (Math.Atan(-_y / -_x) * do_180_div_pi) + 180d;
                }
                return (Math.Atan(-_x / _y) * do_180_div_pi) + 90d;
            }
            if (_y < 0d)
            {
                return (Math.Atan(_x / -_y) * do_180_div_pi) + 270d;
            }
            return Math.Atan(_y / _x) * do_180_div_pi;
        }





        public static float d_set(float _Dir)
        {
            return (float)d_set((double)_Dir);
        }
        public static double d_set(double _Dir)
        {
            if (_Dir < 0d)
            {
                _Dir = 360d - ((-_Dir) % 360d);
            }
            if (_Dir >= 360d)
            {
                return _Dir % 360d;
            }
            return _Dir;
        }


        public static float d_lerp(float From_Direction, float to_Direction, float Rotate_Value)
        {
            return (float)d_lerp((double)From_Direction, (double)to_Direction, (double)Rotate_Value);
        }
        public static double d_lerp(double From_Direction, double to_Direction, double Rotate_Value)
        {
            double _t = d_set_a(to_Direction - From_Direction);
            //From_Direction=d_set(From_Direction);
            //to_Direction=d_set(to_Direction);
            if (Rotate_Value < 0d)
            {
                to_Direction = d_set(to_Direction + 180d);
                Rotate_Value = -Rotate_Value;
            }
            if (abs(_t) <= Rotate_Value)
            {
                return d_set(to_Direction);
            }
            //if(_t<180d)
            if (_t > 0d)
            {
                return d_set(From_Direction + Rotate_Value);
            }
            return d_set(From_Direction - Rotate_Value);
        }
        public static float sc_dir_set_lerp(float From_Direction, float to_Direction, float Value)
        {
            return d_lerp(From_Direction, to_Direction, Value);
        }

        public static float sc_dir_set(float _Direction)
        {
            return d_set(_Direction);
        }
        public static int sc_dir_set(int _Direction)
        {
            return (int)sc_dir_set((float)_Direction);
        }
        public static float d_set_a(float _Direction)
        {
            return (float)d_set_a((double)_Direction);
        }
        public static double d_set_a(double _Direction)
        {
            if (_Direction > 180d)
            {
                return ((_Direction + 180d) % 360d) - 180d;
            }
            if (_Direction <= -180d)
            {
                return 180d - ((180d - _Direction) % 360d);
            }
            return _Direction;

        }
        public static float sc_dir_set_a(float _Direction)
        {
            return d_set_a(_Direction);
        }

        public static float sc_dir_unity_in_moca_out(float _Dir)
        {
            return d_set(360f - _Dir);
        }
        public static float sc_dir_moca_in_unity_out(float _Dir)
        {
            return d_set(360f - _Dir);
        }


        public static float asin(float _Value)
        {
            return (float)(Math.Asin((double)(_Value)));
        }
        public static float acos(float _Value)
        {
            return (float)(Math.Acos((double)(_Value)));
        }
        public static float sin(float _Value)
        {
            return (float)(Math.Sin((double)(_Value)));
        }
        public static float cos(float _Value)
        {
            return (float)(Math.Cos((double)(_Value)));
        }
        public static float tan(float _Value)
        {
            return (float)(Math.Tan((double)(_Value)));
        }
        public static float atan(float _Value)
        {
            return (float)(Math.Atan((double)(_Value)));
        }
        public static float sc_sqr(float _Value)
        {
            return _Value * _Value;
        }
        public static float sqr(float _Value)
        {
            return _Value * _Value;
        }
        public static int sqr(int _Value)
        {
            return _Value * _Value;
        }
        public static double sqr(double _Value, double _n)
        {
            return Math.Pow(_Value, _n);
        }
        public static float sqr(float _Value, float _n)
        {
            return (float)Math.Pow(_Value, _n);
        }
        public static float sqr(float _Value, int _n)
        {
            return (float)Math.Pow(_Value, _n);
        }

        public static double sqrt(double _Value)
        {
            return Math.Sqrt(_Value);
        }
        public static float sqrt(float _Value)
        {
            return (float)Math.Sqrt(_Value);
        }
        /*
  public static float sc_sqr(float _Value,int _n)
  {
   float _t = 1f;
   while (_n>0) 
   {
    _t*=_Value;
    _n--;
   }
   return _t;
  }
  public static float sc_sqr(float _Value,float _n)
  {
   float _t = 1f;
   while (_n>=1) 
   {
    _t*=_Value;
    _n--;
    while (_n>=2) 
    {
     _t*=_Value;
     _n--;
    }
   }
   _t*=_Value/sqr(_Value,1/_n);
   return _Value;
  }
  public static float sc_sqrt(float _Value)
  {
   if (_Value <= 0f) 
   {
    return 0f;
   }
   float _t=1f,_t_save=_t,_t_abs=1f;
   //int i = 0;
   while (_t_abs>0.01f)
   {
    _t_save=_t;
    _t = (_t + (_Value / _t)) / 2f ; 

    _t_abs=_t_save-_t;
    if(_t_abs<0f)
    {
     _t_abs=-_t_abs;
    }
    //i++;
   }
   //Debug.Log ("i:"+i);
   return _t;
   //Newton
   //x_n+1 = x_n - f(x_n)/f'(x_n) = x_n - (x_n^2 - n)/2x_n = (x_n^2+n)/2x_n
   //Babylonia
   //x = (x + (a / x)) / 2  
  }
  */
        public static float sc_abs(float _Value)
        {
            return abs(_Value);
        }
        public static int sc_abs(int _Value)
        {
            return abs(_Value);
        }
        public static long sc_abs(long _Value)
        {
            return abs(_Value);
        }
        public static float abs(float _Value)
        {
            if (_Value < 0f)
            {
                return -_Value;
            }
            return _Value;
        }
        public static int abs(int _Value)
        {
            if (_Value < 0)
            {
                return -_Value;
            }
            return _Value;
        }
        public static long abs(long _Value)
        {
            if (_Value < 0)
            {
                return -_Value;
            }
            return _Value;
        }
        public static double abs(double _Value)
        {
            if (_Value < 0d)
            {
                return -_Value;
            }
            return _Value;
        }
        public static float sc_floor(float _Value)
        {
            return floor(_Value);
        }
        public static float floor(float _Value)
        {
            return _Value - (_Value % 1f);
        }
        public static float floor_HS(float _Value)
        {
            return (float)((int)_Value);
        }
        public static float sc_ceil(float _Value)
        {
            return ceil(_Value);
        }
        public static float ceil(float _Value)
        {
            float _t = (_Value % 1f);
            if (_t > 0f)
            {
                return (_Value - _t) + 1f;
            }
            if (_t < 0f)
            {
                return (_Value - _t) - 1f;
            }
            return sc_floor(_Value);
        }
        public static float ceil_HS(float _Value)
        {
            float _t = (float)((int)_Value);
            if (_Value > _t)
            {
                return _t + 1;
            }
            if (_Value < _t)
            {
                return _t - 1;
            }
            return _t;
        }
        /*
  public static float sc_round_HS(float _Value)
  {
   float _t=(_Value%1f);
   if(_t<0f)
   {
    if(_t>-0.5f)
    {
     return (float)((int)_Value);
    }
    return ((float)((int)_Value))-1f;
   }
   if(_t<0.5f)
   {
    return (float)((int)_Value);
   }
   return ((float)((int)_Value))+1;
  }
  */
        public static float sc_round(float _Value)
        {
            return round(_Value);
        }
        public static float round(float _Value)
        {
            if (abs(_Value % 1f) < 0.5f)
            {
                return sc_floor(_Value);
            }
            return sc_ceil(_Value);
        }
        public static float sc_max(params float[] _array)
        {
            return max(_array);
        }
        public static int sc_max(params int[] _array)
        {
            return max(_array);
        }
        public static float max(params float[] _array)
        {
            int i, _return_num;
            _return_num = 0;
            for (i = 1; i < _array.Length; i++)
            {
                if (_array[i - 1] < _array[i])
                {
                    _return_num = i;
                }
            }
            return _array[_return_num];
        }
        public static int max(params int[] _array)
        {
            int i, _return_num;
            _return_num = 0;
            for (i = 1; i < _array.Length; i++)
            {
                if (_array[i - 1] < _array[i])
                {
                    _return_num = i;
                }
            }
            return _array[_return_num];
        }
        public static float sc_median(params float[] _array)
        {
            return median(_array);
        }
        public static int sc_median(params int[] _array)
        {
            return median(_array);
        }
        public static double median(params double[] _array)
        {
            int i, j, _median_num = (_array.Length - 1) / 2;
            double _t;
            for (j = 0; j <= _median_num; j++)
            {
                for (i = j; i < _array.Length; i++)
                {
                    if (_array[j] > _array[i])
                    {
                        _t = _array[j];
                        _array[j] = _array[i];
                        _array[i] = _t;
                    }
                }
            }
            return _array[_median_num];
        }
        public static float median(params float[] _array)
        {
            int i, j, _median_num = (_array.Length - 1) / 2;
            float _t;
            for (j = 0; j <= _median_num; j++)
            {
                for (i = j; i < _array.Length; i++)
                {
                    if (_array[j] > _array[i])
                    {
                        _t = _array[j];
                        _array[j] = _array[i];
                        _array[i] = _t;
                    }
                }
            }
            /*
   for (j=1; j<=((_array.Length+1)/2); j++) 
   {
    for (i=1; i<=(_array.Length-j); i++) 
    {
     if(_array[i-1]<_array[i])
     {
      _t=_array[i-1];
      _array[i-1]=_array[i];
      _array[i]=_t;
     }
    }
   }
   */
            return _array[_median_num];
        }
        public static int median(params int[] _array)
        {
            return (int)(sc_median(_array));
        }
        public static long median(params long[] _array)
        {
            long i;
            double[] _arr = new double[_array.Length];
            for (i = 0; i < _array.Length; i++)
            {
                _arr[i] = (double)_array[i];
            }
            return (int)(median(_arr));
        }
        public static float sc_min(params float[] _array)
        {
            return min(_array);
        }
        public static int sc_min(params int[] _array)
        {
            return min(_array);
        }
        public static float min(params float[] _array)
        {
            int i, _return_num;
            _return_num = 0;
            for (i = 1; i < _array.Length; i++)
            {
                if (_array[i - 1] > _array[i])
                {
                    _return_num = i;
                }
            }
            return _array[_return_num];
        }
        public static int min(params int[] _array)
        {
            int i, _return_num;
            _return_num = 0;
            for (i = 1; i < _array.Length; i++)
            {
                if (_array[i - 1] > _array[i])
                {
                    _return_num = i;
                }
            }
            return _array[_return_num];
        }
        public static class mDir
        {
        }
        public static class mCamera
        {
        }
        public static class mMath
        {
        }








        public static mStr_screen[] get_number_screen(Bitmap[] img_font_key)
        {
            return get_number(get_screen(), img_font_key);
        }
        public static mStr_screen[] get_number(Bitmap img, Bitmap[] img_font_key)
        {
            //img_search_font를 이용하여 숫자값과 그에 해당하는 좌표를 반환
            mVec2[][] pos = img_search_font(get_screen(), img_font_key);
            bool[][] using_check = new bool[img_font_key.Length][];

            mStr_screen[] _return_number = null;
            int _return_number_num = 0;



            mVec2 pos_t = -mVec2.one;
            int i_save;
            int j_save;
            float dir_save, _tf, _tf2;
            int _t;
            float font_size_wid, font_size_hei;


            int[] pos_i_save = new int[20];
            int[] pos_j_save = new int[pos_i_save.Length];
            int[] pos_ij_dis = new int[pos_i_save.Length];
            int pos_ij_num = 0;


            if (img_font_key.Length >= 10)
            {
                font_size_wid = -1;
                font_size_hei = -1;
                for (int i = 0; i <= 9; i++)
                {
                    if (img_font_key[i].Width > font_size_wid)
                    {
                        font_size_wid = img_font_key[i].Width;
                    }
                    if (img_font_key[i].Height > font_size_hei)
                    {
                        font_size_hei = img_font_key[i].Height;
                    }
                    if (pos[i] != null)
                    {
                        using_check[i] = new bool[pos[i].Length];
                        for (int j = 0; j < pos[i].Length; j++)
                        {
                            using_check[i][j] = false;
                        }
                    }
                }
                while (true)
                {
                    pos_t = -mVec2.one;
                    i_save = -1;
                    j_save = -1;
                    for (int i = 0; i <= 9; i++)
                    {
                        if (pos[i] != null)
                        {
                            for (int j = 0; j < pos[i].Length; j++)
                            {
                                //가장 왼쪽 위의 문자를 구함
                                if (((i_save == -1) || (j_save == -1))
                                    || ((pos[i][j].x <= pos[i_save][j_save].x) && ((pos[i][j].y <= pos[i_save][j_save].y))))
                                {
                                    if (using_check[i][j] == false) //사용하지 않았을경우 한정
                                    {
                                        i_save = i;
                                        j_save = j;
                                    }
                                }
                            }
                        }
                    }
                    if ((i_save == -1) || (j_save == -1)) //남은 문자가 한개도 없음 
                    {
                        break;
                    }
                    else
                    {

                        //새로운 문자열 추가
                        _return_number = array_add_null<mStr_screen>(_return_number, 1);
                        _return_number[_return_number_num].str = i_save.ToString(); //숫자를 더함
                        _return_number[_return_number_num].pos = pos[i_save][j_save]; //좌표를 저장
                        _return_number_num++;

                        using_check[i_save][j_save] = true;//사용체크

                    }


                    dir_save = 180;


                    //가장 가까운 순서대로 정렬
                    //정렬된값은 pos_i_save,pos_j_save,pos_ij_dis,pos_ij_num 에 저장된다


                    while (true) //조건에 만족하는게 다 떨어질때까지 검색
                    {
                        pos_ij_num = 0;
                        for (int i = 0; i <= 9; i++)
                        {
                            if (pos[i] != null)
                            {
                                for (int j = 0; j < pos[i].Length; j++)
                                {
                                    if (using_check[i][j] == false)  //미사용한것 한정으로
                                    {
                                        _tf = p_dis(pos[i][j] - pos[i_save][j_save]);  //거리 측정 

                                        //저장된 값중에 더 먼게 있는지 확인해서 지우고 한칸 밀기


                                        for (int k = 0; k <= pos_ij_num; k++)
                                        {

                                            if ((_tf <= pos_ij_dis[k]) //저장된 값보다 작을경우 
                                                || ((k == pos_ij_num) && (pos_ij_num < pos_i_save.Length))) //혹은 마지막 저장값에 도달시, 대신 20개보다 작아야한다
                                            {


                                                for (int l = min(pos_ij_num, pos_i_save.Length - 1); l >= k + 1; l--) //한칸씩 뒤로 민다
                                                {
                                                    pos_i_save[l] = pos_i_save[l - 1];
                                                    pos_j_save[l] = pos_j_save[l - 1];
                                                    pos_ij_dis[l] = pos_ij_dis[l - 1];
                                                }
                                                //저장
                                                pos_i_save[k] = i;
                                                pos_j_save[k] = j;
                                                pos_ij_dis[k] = (int)_tf;
                                                if (pos_ij_num < pos_i_save.Length)  //20개 이하일때 공간을 1개 증가시킨다
                                                {
                                                    pos_ij_num++;
                                                }
                                                break;

                                            }
                                        }

                                    }
                                }
                            }
                        }





                        //추출한 폰트가 조건에 부합하는지(각도측정)
                        for (int k = 0; k < pos_ij_num; k++)
                        {
                            _tf = str_screen_check(pos[pos_i_save[k]][pos_j_save[k]], pos[i_save][j_save], font_size_wid, font_size_hei, dir_save);
                            if (_tf >= 0)
                            {
                                dir_save = _tf;
                                using_check[pos_i_save[k]][pos_j_save[k]] = true; //사용체크
                                i_save = pos_i_save[k]; //맨 마지막에 사용한 숫자 저장 
                                j_save = pos_j_save[k]; //맨 마지막에 사용한 배열위치 저장 

                                _return_number[_return_number_num - 1].str += pos_i_save[k];//문자열에 추가
                                goto GET_NUMBER_OUT_GOTO;
                            }
                        }
                        //조건에 만족하는게 한개도 없을경우 탈출
                        break;


                    GET_NUMBER_OUT_GOTO:;
                        //한개이상 있을경우 루프 
                    }





                }




            }
            return _return_number;
        }
        private static float str_screen_check(mVec2 pos, mVec2 pos_save, float font_wid, float font_hei, float dir_save)
        {
            float _tf;
            if ((Math.Abs(pos.x - pos_save.x) < (font_wid * 1.2))
                && (Math.Abs(pos.y - pos_save.y) < (font_hei * 1.5)))
            {
                _tf = p_dir(pos - pos_save);
                if (dir_save == 180)
                {
                    if ((_tf > (270 - 50)) || (_tf < 50))
                    {
                        return _tf;
                    }
                }
                else
                {
                    if (Math.Abs(_tf - dir_save) < 35)
                    {
                        return _tf;
                    }
                }
            }
            return -1;
        }
        public static byte get_xor_byte(byte[] input)
        {
            byte return_byte = 0 ;
            long input_LongLength = input.LongLength;

            for (long i=0; i< input_LongLength; i++)
            {
                return_byte ^= input[i];
            }
            return return_byte;
        }
        public static byte[] get_byte(EndPoint EP)
        {
            return get_byte((IPEndPoint)EP);
        }
        public static byte[] get_byte(IPEndPoint EP)
        {
            return array_add<byte>(get_byte(EP.Address), get_byte((ushort)EP.Port));
        }
        public static byte[] get_byte(IPAddress IPA)
        {
            return IPA.GetAddressBytes();
        }
        public static byte[] get_byte(byte input)
        {
            byte[] return_byte = BitConverter.GetBytes(input);
            if (!BitConverter.IsLittleEndian)
            {
                Array.Reverse(return_byte);
            }
            return return_byte;
        }
        public static byte[] get_byte(short input)
        {
            byte[] return_byte = BitConverter.GetBytes(input);
            if (!BitConverter.IsLittleEndian)
            {
                Array.Reverse(return_byte);
            }
            return return_byte;
        }
        public static byte[] get_byte(ushort input)
        {
            byte[] return_byte = BitConverter.GetBytes(input);
            if (!BitConverter.IsLittleEndian)
            {
                Array.Reverse(return_byte);
            }
            return return_byte;
        }
        public static byte[] get_byte(int input)
        {
            byte[] return_byte = BitConverter.GetBytes(input);
            if (!BitConverter.IsLittleEndian)
            {
                Array.Reverse(return_byte);
            }
            return return_byte;
        }
        public static byte[] get_byte(long input)
        {
            byte[] return_byte = BitConverter.GetBytes(input);
            if (!BitConverter.IsLittleEndian)
            {
                Array.Reverse(return_byte);
            }
            return return_byte;
        }
        public static byte[] get_byte(double input)
        {
            byte[] return_byte = BitConverter.GetBytes(input);
            if (!BitConverter.IsLittleEndian)
            {
                Array.Reverse(return_byte);
            }
            return return_byte;
        }
        public static byte[] get_byte(string str)
        {
            return Encoding.UTF8.GetBytes(str);
        }
        public static byte[] get_byte(Bitmap img)
        {



            System.Drawing.Imaging.BitmapData bmpData = img.LockBits(new Rectangle(0, 0, img.Width, img.Height), System.Drawing.Imaging.ImageLockMode.ReadWrite,
            img.PixelFormat);
            IntPtr ptr = bmpData.Scan0;

            // Declare an array to hold the bytes of the bitmap.
            int bytes = Math.Abs(bmpData.Stride) * img.Height;
            byte[] rgbValues = new byte[bytes];

            System.Runtime.InteropServices.Marshal.Copy(ptr, rgbValues, 0, bytes);

            // Copy the RGB values back to the bitmap
            System.Runtime.InteropServices.Marshal.Copy(rgbValues, 0, ptr, bytes);

            // Unlock the bits.
            img.UnlockBits(bmpData);
            return rgbValues;
        }


        public static Bitmap get_img(string file_name)
        {
            return new Bitmap(file_name);
        }
        public static Bitmap[] get_img(string[] file_name)
        {
            if (file_name != null)
            {
                Bitmap[] _return = new Bitmap[file_name.Length];
                for (int i = 0; i < file_name.Length; i++)
                {
                    _return[i] = new Bitmap(file_name[i]);
                }
                return _return;
            }
            return null;
        }


        public static void wait_time(ref long time_save)
        {
            wait_time(ref time_save, 10);
        }
        public static void wait_time(ref long time_save, int wait_ms)
        {
            Thread.Sleep((int)(Math.Max(0, wait_ms - ((DateTime.Now.Ticks - time_save) / 10000))));
            time_save = DateTime.Now.Ticks;
        }
        public static long get_time
        {
            get
            {
                return DateTime.Now.Ticks;
            }
        }
        public static int get_time_h
        {
            get
            {
                return DateTime.Now.Hour;
            }
        }
        public static int get_time_m
        {
            get
            {
                return DateTime.Now.Minute;
            }
        }
        public static int get_time_s
        {
            get
            {
                return DateTime.Now.Second;
            }
        }
        public static string get_number(string str)
        {
            return Regex.Replace(str, @"\D", "");
        }
        public static long get_integer(string str)
        {
            if (str == null)
            {
                return 0;
            }
            str = Regex.Replace(str, @"\D", "");
            if (str == "")
            {
                return 0;
            }
            return long.Parse(str);
        }
        
        public static bool type_check(Type _a, Type _b)
        {
            //type_check(typeof(a),typeof(b))
            return _a.Equals(_b);
        }
        public static bool type_check<T,U>()
        {
            return typeof(T).Equals(typeof(U));
        }

        public static T[] array_slice<T>(T[] _array, long length)
        {
            return array_slice<T>(_array, 0, length);
        }
        public static T[] array_slice<T>(T[] _array, long index, long length)
        {
            if ((length <= 0)|| (_array == null))
            {
                return null;
            }
            if (index < 0)
            {
                index = 0;
            }
            if ((index + length) > _array.Length)
            {
                length = (_array.Length - index);
            }
            
            T[] _array_t = new T[length];
            for (int i = 0; i < length; i++)
            {
                _array_t[i] = _array[i+ index];
            }
            return _array_t;
        }
        public static T[] array_add_null<T>(T[] _array, long num_p)
        {
            if (num_p <= 0)
            {
                return _array;
            }
            if (_array == null)
            {
                _array = new T[num_p];
                return _array;
            }


            int array_len = _array.Length;
            T[] _array_t = new T[array_len + num_p];
            for (int i = 0; i < array_len; i++)
            {
                _array_t[i] = _array[i];
            }
            return _array_t;
        }
        public static T[] array_add<T>(T[] _array, long num_p, params T[] _array_p)
        {
            long _array_p_median = median(0, num_p, _array_p.Length);
            T[] _array_t = new T[_array.Length + _array_p_median];
            for (int i = 0; i < _array.Length; i++)
            {
                _array_t[i] = _array[i];
            }
            for (int i = 0; i < _array_p_median; i++)
            {
                _array_t[i + _array.Length] = _array_p[i];
            }
            return _array_t;
        }
        public static T[] array_add<T>(T[] _array, params T[] _array_p)
        {
            if (_array == null)
            {
                return (T[])_array_p.Clone();
            }
            T[] _array_t = new T[_array.Length + _array_p.Length];
            for (int i = 0; i < _array.Length; i++)
            {
                _array_t[i] = _array[i];
            }
            for (int i = 0; i < _array_p.Length; i++)
            {
                _array_t[i + _array.Length] = _array_p[i];
            }

            return _array_t;
        }
        public static T[] array_add_at<T>(T[] _array,long _index, params T[] _array_p)
        {
            if (_array == null)
            {
                return (T[])_array_p.Clone();
            }
            T[] _array_t = new T[_array.Length + _array_p.Length];
            for (long i = 0; i < _index; i++)
            {
                _array_t[i] = _array[i];
            }
            for (long i = 0; i < _array_p.LongLength; i++)
            {
                _array_t[i + _index] = _array_p[i];
            }
            for (long i = _index; i < _array.Length; i++)
            {
                _array_t[i + _array_p.LongLength] = _array[i];
            }

            return _array_t;
        }
        public static T[] array_delete<T>(T[] _array, int offset)
        {
            return array_delete<T>(_array, offset, 1);
        }
        public static T[] array_delete<T>(T[] _array, int offset, int _Length)
        {
            //offset is 0 ~ (_array.length - 1))
            if (_Length <= 0)
            {
                return _array;
            }
            if ((_array == null) || (_array.Length <= _Length))
            {
                return null;
            }


            T[] _array_t = new T[_array.Length - _Length];
            for (int i = offset; i < _array_t.Length; i++)
            {
                _array_t[i] = _array[i + _Length];
            }
            return _array_t;
        }
        public static string file_search()
        {
            OpenFileDialog openFile = new OpenFileDialog();
            //openFile.DefaultExt = "png";
            openFile.Filter = "All files(*.*)|*.*";
            openFile.ShowDialog();


            if (openFile.FileName.Length > 0)//파일이선택될경우 
            {
                return openFile.FileName;
            }
            return "";
        }
        public static void start_program(string file_name)
        {
            System.Diagnostics.ProcessStartInfo run = new System.Diagnostics.ProcessStartInfo();
            run.FileName = file_name;
            System.Diagnostics.Process.Start(run);

        }


        public static void combo_box_set(ComboBox combobox, params string[] combobox_item)
        {
            combobox.Items.Clear();
            combobox.Items.AddRange(combobox_item);
            combobox.SelectedIndex = 0;
        }

    }

}
