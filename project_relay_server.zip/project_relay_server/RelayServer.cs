﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project_relay_server
{
    public partial class RelayServer : Form
    {
        public static Thread[] _thread = new Thread[20];
        public static int _thread_num = 0;
        public static int text_clear_timer = 0;
        public static List<string> textBox1_log_line = new List<string>();
        public delegate void de_set_userlist(string[] text);
        public delegate void de_set_log(string text);
        public delegate void de_set_port(int input);
        public delegate void de_set_appcode(long input);

        public void set_userlist(string[] input)
        {
            if(input.Length > 50)
            {
                textBox5_userlist.Text= "User is over 50";
            }
            this.Invoke(new Action(delegate ()
            {
                textBox5_userlist.Lines = input;
            }));
        }
        public void set_log(string input)
        {
            
            this.Invoke(new Action(delegate () {
                if (text_clear_timer > 50)
                {
                    //textBox1_log.Clear();
                    textBox1_log.Lines = textBox1_log_line.ToArray();
                    //textBox1_log.AppendText("\r\n");
                    text_clear_timer=0;
                }
                textBox1_log.AppendText("\r\n" + input);
                /*
                textBox1_log.AppendText("\r\n" + input);
                if (textBox1_log.TextLength > 2048)
                {
                    textBox1_log.Text = textBox1_log.Text.Substring(textBox1_log.TextLength - 2048);
                }
                */

            }));


            lock (textBox1_log_line)
            {
                if (textBox1_log_line.Count > 50)
                {
                    textBox1_log_line.RemoveAt(0);
                }
                textBox1_log_line.Add(input);
            }
            text_clear_timer++;
        }
        public void set_port(int input)
        {
            this.Invoke(new Action(delegate () {
                textBox2_port.Text = input.ToString();
            }));
        }
        public void set_appcode(long input)
        {
            this.Invoke(new Action(delegate () {

                textBox3_appcode.Text = input.ToString();

            }));
        }
        private void textBox2_port_TextChanged(object sender, EventArgs e)//문자열 바뀔때.
        {
            //textBox2_port.Text = int.Parse(textBox2_port.Text).ToString();
        }
        private void textBox2_port_KeyUp(object sender, KeyEventArgs e)//키 뗄때.
        {
            if (e.KeyCode == Keys.Enter)//엔터.
            {

                lock (Program2_Net.cmd)
                {
                    Program2_Net.cmd.Add("port:"+textBox2_port.Text);
                }
            }
        }
        private void RelayServer_FormClosing(object sender, FormClosingEventArgs e)
        {
            sc_close();
        }
        public static class handle
        {
            public static de_set_userlist de_set_userlist_handle;
            public static de_set_log de_set_log_handle;
            public static de_set_port de_set_port_handle;
            public static de_set_appcode de_set_appcode_handle;

            
        }
        public void cmd_in()
        {
            set_log("CMD:" + textBox4_cmd.Text);
            
            lock (Program2_Net.cmd)
            {
                Program2_Net.cmd.Add(textBox4_cmd.Text);
            }
            textBox4_cmd.Text = "";
        }
        public RelayServer()
        {

            InitializeComponent();
            handle.de_set_log_handle = new de_set_log(set_log);
            handle.de_set_port_handle = new de_set_port(set_port);
            handle.de_set_appcode_handle = new de_set_appcode(set_appcode);
            handle.de_set_userlist_handle = new de_set_userlist(set_userlist);
            //log.de_set_log_handle("test3");

            thread_start(Program2_Net.loop);
            thread_start(Program2_Net.ping_timing);
            textBox1_log.AppendText("boot success");
            textBox1_log.MaxLength = 256;


            this.textBox2_port.KeyUp += new KeyEventHandler(textBox2_port_KeyUp);
            this.textBox3_appcode.KeyUp += new KeyEventHandler(textBox3_appcode_KeyUp);
            this.textBox4_cmd.KeyUp += new KeyEventHandler(textBox4_cmd_KeyUp);

            this.FormClosing += new FormClosingEventHandler(RelayServer_FormClosing);
        }

        public static void sc_close()
        {
            for(int i=0; i< _thread_num;i++)
            {
                _thread[i].Abort();
            }
            Program2_Net.Destroy();
            Application.Exit();
        }
        public static void thread_start(ThreadStart _ts)
        {


            _thread[_thread_num] = new Thread(_ts); //스레드를 생성
            _thread[_thread_num].IsBackground = true; //백그라운드에서 동작(메인스레드의 하위로 들어감)
            _thread[_thread_num].Priority = ThreadPriority.BelowNormal;  //백그라운드 스레드의 우선순위를 약간 낮음으로 변경
                                                                         //_thread[i].Priority = ThreadPriority.Lowest;  //백그라운드 스레드의 우선순위를 낮음으로 변경(낮을수록 느림)
            _thread[_thread_num].Start(); //스레드 시작
            _thread_num++;

        }
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            sc_close();
            
            //this.ReceiveThread.Abort();
        }

        private void textBox4_cmd_KeyUp(object sender, KeyEventArgs e)//키 뗄때.
        {
            if (e.KeyCode == Keys.Enter)//엔터.
            {

                cmd_in();
            }
        }
        private void textBox3_appcode_KeyUp(object sender, KeyEventArgs e)//키 뗄때.
        {
            if (e.KeyCode == Keys.Enter)//엔터.
            {
                lock (Program2_Net.cmd)
                {
                    Program2_Net.cmd.Add("appcode:" + textBox3_appcode.Text);
                }
            }
        }
        private void button1_cmd_enter_Click(object sender, EventArgs e)
        {
            cmd_in();
        }
    }
}
