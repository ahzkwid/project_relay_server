﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MocaEngine;
using System.Threading;

namespace project_relay_server
{
    static class Program2_Net
    {
        public enum user_state { connecting, matching_wait, EPrecv_ok, end};
        public enum user_reply { connecting_success, matching_wait_ok, matching_success_EPsend, end};

        public static mNet.Server _server = new mNet.Server(mNet.mNetworkType.IPV4, mNet.mProtocolType.UDP, 21200, 1024);
        public static Thread receive_thread = null;
        public static Thread[] receive_thread2 = new Thread[4];
        public static List<string> cmd = new List<string>();
        public static bool running = false;
        public static long appcode = 0;
        public static long matching_size = 2;
        public static long debug = 0; //1= mute
        public static List<_client> _client_list = new List<_client>();
        public static List<string> log_buffer = new List<string>();
        public static List<string> userlist_buffer = new List<string>();

        public static mNet.mUser user_buff = mNet.mUser.None;
        public static mNet.mMessage message_buff = mNet.mMessage.None;
        public static mNet.mMessage send_message_buff = mNet.mMessage.None;
        public static long timer = 0;
        public static long Ping_time_save = DateTime.Now.Ticks;
        public static long Ping_timer = 0;
        public static long AppKey = 0;
        public static long va_traffic = 0;

        public class _client
        {
            public long _id;
            public mNet.mUser _user;
            public long _ping;
            public System.Net.EndPoint EP;
            public List<System.Net.EndPoint> to_EP = new List<System.Net.EndPoint>();
            public List<int> to_hostnumber = new List<int>();
            public int state = (int)user_state.connecting;
            public _client(long ID, long _ping, mNet.mUser _user, System.Net.EndPoint EP)
            {
                this._user = _user;
                this._id = ID;
                this._ping = _ping;
                this.EP = EP;
            }
        }
        public static void Destroy()
        {
            if (receive_thread != null)
            {
                receive_thread.Abort();
            }
            for(int i=0;i<5; i++)
            {
                if (receive_thread2[i] != null)
                {
                    receive_thread2[i].Abort();
                }
            }
            _server.Close();
        }
        public static void server_receive()
        {
            System.Net.EndPoint receive_ep = new System.Net.IPEndPoint(System.Net.IPAddress.None, 0);
            int receive_bytes_size = 1024*24;
            byte[] receive_bytes = new byte[receive_bytes_size];
            byte[] ping_bytes = new byte[] { 112, 105, 110, 103 };
            byte[] toip_bytes = new byte[] { 116, 111, 105, 112 };
            mByteBuffer send_t = new mByteBuffer(receive_bytes);

            int receive_size = 0;

            byte[] bt_t;
            byte[] bt_t_reve_ip;
            byte[] bt_t_to_ip;
            while (true)
            {
                try
                {
                    receive_ep = new System.Net.IPEndPoint(System.Net.IPAddress.None, 0);

                    receive_size = _server.Socket.ReceiveFrom(receive_bytes, ref receive_ep);
                    
                    switch (debug)
                    {
                        case 0:
                            break;
                        case 2:
                            /*
                            if (debug == 2)
                            {

                                string str_t = "";
                                for (int i = 0; i < receive_size; i++)
                                {
                                    str_t += "," + receive_bytes[i];
                                }
                                log(str_t);

                            }
                            */
                            log("receive size:" + receive_size + ",ip=" + receive_ep.ToString());
                            if ((debug == 2)&& (receive_size >=96))
                            {

                                string str_t = "";
                                mByteBuffer t = new mByteBuffer(receive_bytes);
                                str_t += "," + t.Read<string>();
                                str_t += "," + t.Read<int>();
                                str_t += "," + t.Read<int>();
                                str_t += "," + t.Read<byte>();
                                str_t += "," + t.Read<int>();
                                str_t += "," + t.Read<int>();
                                str_t += "," + t.Read<string>();
                                str_t += "," + t.Read<int>();
                                str_t += "," + t.Read<int>();
                                str_t += "," + t.Read<byte>();
                                str_t += "," + t.Read<byte>();
                                for (int i = 0; i < receive_size; i++)
                                {
                                    str_t += "," + receive_bytes[i];
                                }
                                log(str_t);

                            }
                            /*
                            mByteBuffer t = new mByteBuffer(receive_bytes);
                            str_t += "," + t.Read<string>();
                            str_t += "," + t.Read<long>();
                            str_t += "," + t.Read<long>();
                            str_t += "," + t.Read<byte>();
                            str_t += "," + t.Read<long>();
                            str_t += "," + t.Read<long>();
                            str_t += "," + t.Read<string>();
                            str_t += "," + t.Read<long>();
                            str_t += "," + t.Read<long>();
                            str_t += "," + t.Read<byte>();
                            str_t += "," + t.Read<byte>();
                            */
                            //_server.Socket.SendTo(new byte[] { 50, 111, 116, 107 }, user_buff.EndPoint
                            //_server.Socket.SendTo(receive_bytes, receive_ep);
                            break;
                    }
                    if (receive_size > 0)
                    {
                        va_traffic += receive_size;
                        if (ping_bytes.Length== receive_size)
                        {
                            if((ping_bytes[0]== receive_bytes[0])&& (ping_bytes[1] == receive_bytes[1])
                                    && (ping_bytes[2] == receive_bytes[2]) && (ping_bytes[3] == receive_bytes[3]))
                            {
                                _server.Socket.SendTo(ping_bytes, receive_ep);
                            }
                            
                        }
                        else if ((receive_size > 4)
                                    && ((toip_bytes[0] == receive_bytes[0]) && (toip_bytes[1] == receive_bytes[1])&& (toip_bytes[2] == receive_bytes[2]) && (toip_bytes[3] == receive_bytes[3]))
                                    ||((toip_bytes[0] == receive_bytes[4]) && (toip_bytes[1] == receive_bytes[5])&& (toip_bytes[2] == receive_bytes[6]) && (toip_bytes[3] == receive_bytes[7]))
                                    && (va_traffic<(1024*1024*3)))//4mb/s
                        {
                            bt_t = mScript.array_slice<byte>(receive_bytes, receive_size);
                            bt_t_reve_ip = mScript.get_byte(receive_ep);
                            bt_t_to_ip = new byte[bt_t.Length];
                            int t = 4;
                            if (toip_bytes[0] == receive_bytes[4])
                            {
                                t = 8;
                            }
                            for (int i = 0; i < bt_t_reve_ip.Length; i++)
                            {
                                bt_t_to_ip[i] = bt_t[t + i];
                                bt_t[t + i] = bt_t_reve_ip[i];
                            }
                            if (bt_t_to_ip[0]!=127)
                            {
                                System.Net.EndPoint to_ep = new System.Net.IPEndPoint(new System.Net.IPAddress(new byte[] { bt_t_to_ip[0], bt_t_to_ip[1], bt_t_to_ip[2], bt_t_to_ip[3] }), (int)BitConverter.ToUInt16(bt_t_to_ip, 4));
                                _server.Socket.SendTo(bt_t, to_ep);
                                va_traffic += receive_size;
                                if (debug == 2)
                                {
                                    log("" + receive_ep + " to " + to_ep + ",byte:" + bt_t.Length);
                                }
                            }
                        }
                        else
                        {
                            log("receive size:" + receive_size + ",ip=" + receive_ep.ToString());
                            lock(_server)
                            {
                                _server.AddMessage(receive_ep, mScript.array_slice<byte>(receive_bytes, receive_size));
                            }
                        }
                        /*
                        if (receive_buff_size == 0)
                        {
                            for (int i = 0; i < receive_size; i++)
                            {
                                receive_buff[i] = receive_bytes[i];
                            }
                            receive_buff_size = receive_size;
                        }
                        */
                        //_server.Socket.SendTo(ping_bytes, receive_ep);
                    }
                }
                catch (System.Net.Sockets.SocketException e)
                {
                    if (e.ErrorCode == 10040)//버퍼가 작음
                    {
                        if (receive_bytes_size < 65507)//UDP송수신한계65507, TCP는 65535인듯.
                        {
                            receive_bytes_size = Math.Min(65507, receive_bytes_size * 2);

                        }
                        receive_bytes = new byte[receive_bytes_size];
                    }
                }
            }
        }
        public static void client_list_step()
        {
            userlist_buffer.Clear();
            for (int i = 0; i < _client_list.Count; i++)
            {
                userlist_buffer.Add(_client_list[i]._user.Name+"("+ _client_list[i].EP.ToString()+")");
            }
            RelayServer.handle.de_set_userlist_handle(userlist_buffer.ToArray());

        }
        public static void log_send()
        {
            if (debug != 1)
            {
                for(int i=0;i< log_buffer.Count;i++)
                {
                    RelayServer.handle.de_set_log_handle(log_buffer[i]);
                }
                log_buffer.Clear();
            }
        }

        public static void log(string input)
        {
            if(debug!=1)
            {
                log_buffer.Add(input);
                //RelayServer.handle.de_set_log_handle(input);
            }
        }

        public static int UserAdd(mNet.mUser _user)
        {
            if (AppKey != 0)
            {
                if (AppKey != _user.AppKey)
                {
                    return 100;
                }
            }
            int id = Math.Min((int)_user.ID, _client_list.Count-1);
            _user.ID = id;
            if (id < 0)
            {
                for (int i = 0; i < _client_list.Count; i++)
                {
                    if (_client_list[i].EP.Equals(  _user.EndPoint))
                    {
                        return 101;
                    }
                }
                mNet.mUser input_user = new mNet.mUser(_user.HashKey, _user.Name, _user.AppKey, _user.EndPoint);
                _client input = new _client(_client_list.Count-1, Ping_timer, input_user, _user.EndPoint);
                _client_list.Add(input);
                return 0;
            }
            else
            {
                if ((_client_list[id]._user.Name != _user.Name)
                    || (_client_list[id]._user.HashKey != _user.HashKey))
                {

                    for (int i = 0; i < _client_list.Count; i++)
                    {
                        if ((_client_list[i]._user.Name == _user.Name)
                            &&(_client_list[i]._user.HashKey == _user.HashKey))
                        {
                            _client_list[i]._user.ID = i;
                            _client_list[i].EP = _user.EndPoint;
                            _client_list[i]._ping = Ping_timer;
                            return 3;
                        }
                    }
                    return 102;
                }

                _client_list[id]._ping = Ping_timer;
                if (!_client_list[id].EP .Equals(_user.EndPoint))
                {
                    _client_list[id].EP = _user.EndPoint;
                    return 2;
                }

                return 1;
                

            }
        }
        public static void message_read(int error_num)
        {
            switch(error_num)
            {
                case 1: //매칭대기중.
                case 2: //매칭대기중IP바뀜.
                    break;
                default:
                    return;
            }
            long id = Math.Min((int)user_buff.ID, _client_list.Count - 1);
            //long id = user_buff.ID;
            _client_list[(int)id].state = message_buff._buffer.Read<int>();
            /*
            switch (message_buff._buffer.Read<int>())
            {
                case 0://신규가입,기타.
                    break;
                case 1://클라이언트 리스트.
                    //_client_list.Add(new _client(user_buff.ID, Ping_timer, user_buff, user_buff.EndPoint));
                    break;
                case 2://매칭 대기중.
                    break;
                case 3://매칭중.
                    break;
                case 4://매칭완료 홀펀칭 핑.
                    break;
                case 5://연결종료
                    break;
            }
            LIST_CHECK_END_DNWIDHSFKA:;


            send_message_buff._buffer.Delete();
            if (error_num==0)
            {
                send_message_buff._buffer.Add((long)_server.UserList.Count);
            }
            else
            {
                send_message_buff._buffer.Add((long)id);
            }
            send_message_buff._buffer.Add((long)0);//state

            _server.Send(send_message_buff._buffer, message_buff.EP);
            //buff.Read<Long>();
            */
        }
        public static void message_check()
        {
            int rt_t = 0;
            for(int i=0;i<1000;i++)
            {
                rt_t = _server.ReadMessage(ref message_buff);
                if (rt_t < 100)
                {

                    if (debug == 2)
                    {

                        log("ReadMessage Error num:" + rt_t);
                    }
                    rt_t = message_buff.UnRapping(ref user_buff);

                    if (debug == 2)
                    {
                        log("UnRapping Error num:" + rt_t);
                    }
                    
                    if (rt_t < 100)
                    {
                        rt_t = UserAdd(user_buff);

                        if (debug == 2)
                        {
                            log("UserAdd Error num:" + rt_t);
                        }
                        message_read( rt_t);
                    }
                    else if (rt_t < 200)
                    {
                        //log("UnRapping Error num:" + rt_t +", len:"+ message_buff._buffer.Lenght);
                        //_server.Send(,user_buff.EndPoint);
                    }
                    message_buff.Delete();
                    break;
                }
                else
                {
                    break;
                }
            }
        }
        public static void cmd_check()
        {
            if(cmd!=null)
            {
                if (cmd.Count > 0)
                {
                    if (cmd[0].IndexOf("port:") != -1)
                    {
                        if (running == false)
                        {
                            _server.Port = int.Parse(System.Text.RegularExpressions.Regex.Replace(cmd[0], @"\D", ""));
                            log("success::port is "+ _server.Port);
                        }
                        else
                        {
                            log("fail::server is running");
                        }
                        RelayServer.handle.de_set_port_handle(_server.Port);
                        cmd.RemoveAt(0);
                        return;
                    }
                }
                if (cmd.Count > 0)
                {
                    if (cmd[0]== "start")
                    {
                        if(running == false)
                        {
                            _server.Bind();
                            receive_thread = new Thread(server_receive);
                            receive_thread.IsBackground = true;
                            //receive_thread.Priority = ThreadPriority.BelowNormal;
                            receive_thread.Start();
                            for(int i=0;i< receive_thread2.Length;i++)
                            {
                                receive_thread2[i] = new Thread(server_receive);
                                receive_thread.IsBackground = true;
                                //receive_thread.Priority = ThreadPriority.BelowNormal;
                                receive_thread2[i].Start();
                            }
                            running = true;
                            log("success");
                            log("appcode : " + appcode);
                            log("port :" + _server.Port);
                            log("matching size : " + matching_size);
                            
                        }
                        else
                        {
                            log("fail::server is running");
                        }
                        cmd.RemoveAt(0);
                        return;
                    }
                }
                if (cmd.Count > 0)
                {
                    if (cmd[0].IndexOf("appcode:") != -1)
                    {
                        appcode = long.Parse(System.Text.RegularExpressions.Regex.Replace(cmd[0], @"\D", ""));
                        AppKey=appcode;
                        log("success::appcode is " + appcode);
                        RelayServer.handle.de_set_appcode_handle(appcode);
                        cmd.RemoveAt(0);
                        return;
                    }
                }
                if (cmd.Count > 0)
                {
                    if (cmd[0].IndexOf("matching size:") != -1)
                    {
                        matching_size = long.Parse(System.Text.RegularExpressions.Regex.Replace(cmd[0], @"\D", ""));
                        log("success::matching size is " + matching_size);
                        cmd.RemoveAt(0);
                        return;
                    }
                }
                if (cmd.Count > 0)
                {
                    if (cmd[0].IndexOf("debug:mute") != -1)
                    {
                        debug = 1;
                        RelayServer.handle.de_set_log_handle("success::debug = " + debug);
                        cmd.RemoveAt(0);
                        return;
                    }
                    else if (cmd[0].IndexOf("debug:") != -1)
                    {
                        debug = long.Parse(System.Text.RegularExpressions.Regex.Replace(cmd[0], @"\D", ""));
                        RelayServer.handle.de_set_log_handle("success::debug = " + debug);
                        cmd.RemoveAt(0);
                        return;
                    }
                }


                if (cmd.Count > 0)
                {
                    if (cmd[0].IndexOf("domain check:") != -1)
                    {

                        log("-------IP-------");
                        foreach (System.Net.IPAddress ip_t in mNet.get_ip(cmd[0].Substring("domain check:".Length)))
                        {
                            if (ip_t.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                            {
                                log(">>" + ip_t.ToString());
                            }
                            else
                            {
                                log("     " + ip_t.ToString());
                            }
                        }
                        log("----------------");
                        cmd.RemoveAt(0);
                        return;
                    }
                }
                if (cmd.Count > 0)
                {
                    cmd.RemoveAt(0);
                    return;
                }


                }
            //System.Threading.Thread.Sleep(2000);
        }

        public static void list_check()
        {
            List<int> maching_list =new List<int>();
            for (int i = 0; i < _client_list.Count; i++)
            {
                if ((Ping_timer - _client_list[i]._ping) > 5)// 5 second
                {
                    _client_list.RemoveAt(i);
                }
            }
            for (int i = 0; i < _client_list.Count; i++)//매칭검색시작.
            {
                switch (_client_list[i].state)
                {
                    case (int)user_state.connecting:
                        break;
                    case (int)user_state.matching_wait:

                        if((_client_list[i].to_EP.Count == 0)//매칭이 안 잡혀있을때.
                            && ((Ping_timer - _client_list[i]._ping) <= 2))// 핑이 낮아야함
                        {
                            if((_client_list.Count-i) >= matching_size) //나를 포함한 인구가 매칭인구와 같거나 클때.
                            {
                                if(maching_list.Count>0)
                                {
                                    maching_list.Clear();//리스트 초기화
                                }
                                for (int j = i; j < _client_list.Count;j++)//매칭을 원하는 인원이 얼마나 되는지.
                                {
                                    if ((_client_list[j].state == (int)user_state.matching_wait)//원하는인원인지
                                        && ((Ping_timer - _client_list[j]._ping) <= 2)// 핑이 낮아야함
                                        && (_client_list[j].to_EP.Count == 0))//매칭이 안잡혀있어야함.
                                    { 
                                        maching_list.Add(j); //그 리스트들
                                        if(maching_list.Count>= matching_size)//매칭인원달성시 중지.
                                        {
                                            break;
                                        }
                                    }
                                }
                                if (maching_list.Count >= matching_size)//매칭인원달성시
                                {
                                    for (int j = 0; j < maching_list.Count; j++)//검색된 리스트들에게 리스트를 나눠줌
                                    {
                                        for (int k = 0; k < maching_list.Count; k++)//나눠주는작업
                                        {
                                            if (k != j)//내거만 빼고
                                            {
                                                _client_list[maching_list[j]].to_hostnumber.Add(k);
                                                _client_list[maching_list[j]].to_EP.Add(_client_list[maching_list[k]].EP);
                                            }
                                        }
                                    }
                                }
                                maching_list.Clear();
                            }
                        }
                        break;
                    case (int)user_state.EPrecv_ok:
                        break;
                    case (int)user_state.end:
                        _client_list.RemoveAt(i);
                        continue;
                }
            }
        }
        public static void message_send()
        {
            
            for (int i = 0; i<_client_list.Count;i++)
            {

                send_message_buff._buffer.Delete();
                switch (_client_list[i].state)
                {
                    case (int)user_state.connecting:
                        send_message_buff._buffer.Add((int)user_reply.connecting_success);
                        break;
                    case (int)user_state.matching_wait:
                        if (_client_list[i].to_EP.Count > 0)
                        {
                            send_message_buff._buffer.Add((int)user_reply.matching_success_EPsend);
                            send_message_buff._buffer.Add((int)_client_list[i].to_EP.Count);
                            for (int j=0;j< _client_list[i].to_EP.Count;j++)
                            {
                                send_message_buff._buffer.Add((int)_client_list[i].to_hostnumber[j]);
                                send_message_buff._buffer.Add(_client_list[i].to_EP[j]);
                            }
                        }
                        else
                        {
                            send_message_buff._buffer.Add((int)user_reply.matching_wait_ok);
                        }
                        break;
                    case (int)user_state.EPrecv_ok:
                        send_message_buff._buffer.Add((int)user_reply.end);
                        break;
                    case (int)user_state.end:
                        continue;
                    default:
                        continue;
                }
                //send_message_buff.EP = _client_list[i].EP;
                //send_message_buff.Rapping(_client_list[i]._user);
                _client_list[i]._user.ID = i;
                _server.Send(send_message_buff.Rapping(_client_list[i]._user), _client_list[i].EP);
            }
        }

        public static void begin_step()
        {

        }

        public static void start()
        {
            RelayServer.handle.de_set_port_handle(_server.Port);
            RelayServer.handle.de_set_appcode_handle(appcode);

            log("-------IP-------");
            foreach (System.Net.IPAddress ip_t in mNet.get_ip())
            {
                if (ip_t.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                {
                    log(">>" + ip_t.ToString());
                }
                else
                {
                    log("     " + ip_t.ToString());
                }
            }
            log("---Command---"); //#은 숫자 @은 문자.
            log("start");
            log("port: ###");
            log("appcode: ###");
            log("matching size: ###");//몇명씩 매칭잡을지.
            log("debug: ### ");
            log("debug:mute ");//로그가 뜨지 않음.
            log("domain check: @@@###");
            log("----------------");
            /*
            System.Net.EndPoint t3 = new System.Net.IPEndPoint(System.Net.IPAddress.Parse("192.168.0.1"), 65535);
            byte[] t = mScript.get_byte(t3);
            string t2 = "";
            for (int i=0; i< t.Length;i++)
            {
                t2+=","+t[i];
            }
            log(t2);
            mByteBuffer t4 = new mByteBuffer();
            t4.Add((int)65535);
            t4.Add((ushort)65535);
            t4.Add((long)65535);
            t = (byte[])t4;

            t2 = "";
            for (int i = 0; i < t.Length; i++)
            {
                t2 += "," + t[i];
            }
            log(t2);
            t2 = "";
            t2 += BitConverter.IsLittleEndian;
            t2 += ""+BitConverter.ToInt32(t,0);
            t2 += "," + BitConverter.ToUInt16(t, 4);
            t2 += "," + BitConverter.ToInt64(t, 6);
            log(t2);
            System.Net.EndPoint t3 = new System.Net.IPEndPoint(System.Net.IPAddress.Parse("192.168.0.1"), 65535);
            byte[] t = mScript.get_byte("toip");
            string t2 = "";
            for (int i = 0; i < t.Length; i++)
            {
                t2 += "," + t[i];
            }
            log(t2);
            */

        }
        public static void step()
        {
            if((timer%10)==0)
            {
                cmd_check();
            }
            message_check();
            list_check();
            message_send();
            //System.Threading.Thread.Sleep(2000);
            timer++;

            if ((timer % 100) == 0)
            {
                log_send();
                client_list_step();

                Ping_timer++;


            }
            if (((DateTime.Now.Ticks- Ping_time_save)/10000 )> 1000)
            {
                
                if (va_traffic > 1024 * 1024)
                {
                    log("traffic:" + (va_traffic / (1024 * 1024)) + "mb");
                }
                else if (va_traffic > 1024)
                {
                    log("traffic:" + (va_traffic / 1024) + "kb");
                }
                va_traffic = 0;
                Ping_time_save = DateTime.Now.Ticks;
            }
            }

        public static void ping_timing()
        {
            Thread.Sleep(1000);
        }
            
        public static void loop()
        {
            Thread.Sleep(100);
            start();
            long time_save = mScript.get_time;
            while (true)
            {
                begin_step();
                step();
                mScript.wait_time(ref time_save, 10); //*100 speed
                //High Speed
            }

        }
    }
}
