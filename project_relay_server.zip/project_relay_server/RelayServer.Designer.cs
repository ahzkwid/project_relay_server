﻿namespace project_relay_server
{

    partial class RelayServer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.파일ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.textBox1_log = new System.Windows.Forms.TextBox();
            this.textBox2_port = new System.Windows.Forms.TextBox();
            this.label1_port = new System.Windows.Forms.Label();
            this.label2_appcode = new System.Windows.Forms.Label();
            this.textBox3_appcode = new System.Windows.Forms.TextBox();
            this.textBox4_cmd = new System.Windows.Forms.TextBox();
            this.button1_cmd_enter = new System.Windows.Forms.Button();
            this.textBox5_userlist = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.파일ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(464, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 파일ToolStripMenuItem
            // 
            this.파일ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveToolStripMenuItem,
            this.loadToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.파일ToolStripMenuItem.Name = "파일ToolStripMenuItem";
            this.파일ToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.파일ToolStripMenuItem.Text = "File";
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.saveToolStripMenuItem.Text = "Save";
            // 
            // loadToolStripMenuItem
            // 
            this.loadToolStripMenuItem.Name = "loadToolStripMenuItem";
            this.loadToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.loadToolStripMenuItem.Text = "Load";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // textBox1_log
            // 
            this.textBox1_log.Location = new System.Drawing.Point(12, 54);
            this.textBox1_log.Multiline = true;
            this.textBox1_log.Name = "textBox1_log";
            this.textBox1_log.ReadOnly = true;
            this.textBox1_log.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox1_log.Size = new System.Drawing.Size(334, 189);
            this.textBox1_log.TabIndex = 1;
            // 
            // textBox2_port
            // 
            this.textBox2_port.Location = new System.Drawing.Point(352, 27);
            this.textBox2_port.Name = "textBox2_port";
            this.textBox2_port.Size = new System.Drawing.Size(100, 21);
            this.textBox2_port.TabIndex = 2;
            // 
            // label1_port
            // 
            this.label1_port.AutoSize = true;
            this.label1_port.Location = new System.Drawing.Point(319, 30);
            this.label1_port.Name = "label1_port";
            this.label1_port.Size = new System.Drawing.Size(27, 12);
            this.label1_port.TabIndex = 3;
            this.label1_port.Text = "Port";
            // 
            // label2_appcode
            // 
            this.label2_appcode.AutoSize = true;
            this.label2_appcode.Location = new System.Drawing.Point(12, 30);
            this.label2_appcode.Name = "label2_appcode";
            this.label2_appcode.Size = new System.Drawing.Size(57, 12);
            this.label2_appcode.TabIndex = 4;
            this.label2_appcode.Text = "AppCode";
            // 
            // textBox3_appcode
            // 
            this.textBox3_appcode.Location = new System.Drawing.Point(75, 27);
            this.textBox3_appcode.Name = "textBox3_appcode";
            this.textBox3_appcode.Size = new System.Drawing.Size(238, 21);
            this.textBox3_appcode.TabIndex = 5;
            // 
            // textBox4_cmd
            // 
            this.textBox4_cmd.Location = new System.Drawing.Point(12, 250);
            this.textBox4_cmd.Name = "textBox4_cmd";
            this.textBox4_cmd.Size = new System.Drawing.Size(359, 21);
            this.textBox4_cmd.TabIndex = 6;
            // 
            // button1_cmd_enter
            // 
            this.button1_cmd_enter.Location = new System.Drawing.Point(377, 250);
            this.button1_cmd_enter.Name = "button1_cmd_enter";
            this.button1_cmd_enter.Size = new System.Drawing.Size(75, 23);
            this.button1_cmd_enter.TabIndex = 7;
            this.button1_cmd_enter.Text = "Enter";
            this.button1_cmd_enter.UseVisualStyleBackColor = true;
            this.button1_cmd_enter.Click += new System.EventHandler(this.button1_cmd_enter_Click);
            // 
            // textBox5_userlist
            // 
            this.textBox5_userlist.Location = new System.Drawing.Point(352, 72);
            this.textBox5_userlist.Multiline = true;
            this.textBox5_userlist.Name = "textBox5_userlist";
            this.textBox5_userlist.ReadOnly = true;
            this.textBox5_userlist.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox5_userlist.Size = new System.Drawing.Size(100, 171);
            this.textBox5_userlist.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(375, 57);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 12);
            this.label1.TabIndex = 9;
            this.label1.Text = "User List";
            // 
            // RelayServer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(464, 281);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox5_userlist);
            this.Controls.Add(this.button1_cmd_enter);
            this.Controls.Add(this.textBox4_cmd);
            this.Controls.Add(this.textBox3_appcode);
            this.Controls.Add(this.label2_appcode);
            this.Controls.Add(this.label1_port);
            this.Controls.Add(this.textBox2_port);
            this.Controls.Add(this.textBox1_log);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "RelayServer";
            this.Text = "Relay Server";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 파일ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.TextBox textBox1_log;
        private System.Windows.Forms.TextBox textBox2_port;
        private System.Windows.Forms.Label label1_port;
        private System.Windows.Forms.Label label2_appcode;
        private System.Windows.Forms.TextBox textBox3_appcode;
        private System.Windows.Forms.TextBox textBox4_cmd;
        private System.Windows.Forms.Button button1_cmd_enter;
        private System.Windows.Forms.TextBox textBox5_userlist;
        private System.Windows.Forms.Label label1;
    }
}

